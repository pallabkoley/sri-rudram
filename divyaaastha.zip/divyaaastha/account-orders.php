<?php
require_once __DIR__ . '/config/config.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action'])) {
    require BASE_PATH . '/includes/handlers/cart-handler.php';
}

require_login();

$stmt = $pdo->prepare('SELECT * FROM orders WHERE user_id = ? ORDER BY created_at DESC');
$stmt->execute([current_user_id()]);
$orders = $stmt->fetchAll();

$pageTitle = 'My Orders — ' . APP_NAME;
require BASE_PATH . '/includes/header.php';
?>

<section class="page-hero">
  <div class="page-hero-mandala"></div>
  <div class="container">
    <nav class="breadcrumb">
      <a href="<?= url('index.php') ?>">Home</a>
      <span class="sep">›</span>
      <a href="<?= url('account.php') ?>">Account</a>
      <span class="sep">›</span>
      <span class="current">Orders</span>
    </nav>
    <h1>My Orders</h1>
  </div>
</section>

<section class="section">
  <div class="container">
    <div class="account-grid">
      <aside class="account-nav">
        <a href="<?= url('account.php') ?>">👤 Dashboard</a>
        <a href="<?= url('account-orders.php') ?>" class="active">📦 My Orders</a>
        <a href="<?= url('account-bookings.php') ?>">🙏 My Bookings</a>
        <a href="<?= url('wishlist.php') ?>">♡ Wishlist</a>
        <a href="<?= url('logout.php') ?>">🚪 Logout</a>
      </aside>

      <div class="account-main">
        <h1>Orders</h1>
        <p class="sub"><?= count($orders) ?> order<?= count($orders) === 1 ? '' : 's' ?> found</p>

        <?php if (empty($orders)): ?>
          <div class="cart-empty" style="padding:60px 30px">
            <div class="om" style="font-size:42px">📦</div>
            <h3>No orders yet</h3>
            <p>Start shopping from our Siddha Store.</p>
            <a href="<?= url('shop.php') ?>" class="btn btn-terra">Explore Store</a>
          </div>
        <?php else: ?>
          <?php foreach ($orders as $o): ?>
            <div class="order-card">
              <div class="order-card-head">
                <b>#<?= e($o['order_number']) ?></b>
                <span class="order-status <?= e($o['status']) ?>"><?= e($o['status']) ?></span>
              </div>
              <div style="display:flex;justify-content:space-between;align-items:center;flex-wrap:wrap;gap:12px">
                <span style="font-size:12.6px;color:var(--muted)">
                  <?= date('d M Y', strtotime($o['created_at'])) ?>
                </span>
                <span style="font-family:'Playfair Display',serif;font-size:18px;color:var(--terracotta);font-weight:700">
                  <?= inr($o['total']) ?>
                </span>
              </div>
            </div>
          <?php endforeach; ?>
        <?php endif; ?>
      </div>
    </div>
  </div>
</section>

<?php require BASE_PATH . '/includes/footer.php'; ?>