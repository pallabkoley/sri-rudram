<?php
require_once __DIR__ . '/config/config.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action'])) {
    require BASE_PATH . '/includes/handlers/cart-handler.php';
    require BASE_PATH . '/includes/handlers/puja-book-handler.php';
}

$slug = $_GET['slug'] ?? '';
$puja = get_puja_by_slug($slug);

if (!$puja) {
    http_response_code(404);
    require BASE_PATH . '/404.php';
    exit;
}

$pageTitle = $puja['name'] . ' — Book Online Puja';
$pageDesc  = $puja['short_desc'] ?? '';
require BASE_PATH . '/includes/header.php';
?>

<section class="page-hero">
  <div class="page-hero-mandala"></div>
  <div class="container">
    <nav class="breadcrumb">
      <a href="<?= url('index.php') ?>">Home</a>
      <span class="sep">›</span>
      <a href="<?= url('pujas.php') ?>">Puja</a>
      <span class="sep">›</span>
      <span class="current"><?= e($puja['name']) ?></span>
    </nav>
  </div>
</section>

<section class="container">
  <div class="detail-grid">
    <div class="detail-media">
      <?= img_tag($puja['image_url'], $puja['name'], '', false) ?>
      <?php if (!empty($puja['badge'])): ?>
        <span class="badge-overlay"><?= e($puja['badge']) ?></span>
      <?php endif; ?>
    </div>

    <div class="detail-info">
      <h1><?= e($puja['name']) ?></h1>

      <div class="detail-meta">
        <?php if (!empty($puja['temple_name'])): ?>
          <span class="m-item">🛕 <b><?= e($puja['temple_name']) ?></b></span>
        <?php endif; ?>
        <?php if (!empty($puja['city'])): ?>
          <span class="m-item">📍 <?= e($puja['city']) ?>, <?= e($puja['state']) ?></span>
        <?php endif; ?>
        <?php if (!empty($puja['duration_mins'])): ?>
          <span class="m-item">⏱ <b><?= (int) $puja['duration_mins'] ?> min</b> ritual</span>
        <?php endif; ?>
      </div>

      <div class="detail-price">
        <span class="now"><?= inr($puja['price']) ?></span>
        <span style="color:var(--muted);font-size:13px">includes prasad delivery</span>
      </div>

      <div class="detail-desc">
        <p><?= e($puja['short_desc']) ?></p>
        <?php if (!empty($puja['description'])): ?>
          <h3>About this Puja</h3>
          <p><?= nl2br(e($puja['description'])) ?></p>
        <?php endif; ?>

        <h3>What's Included</h3>
        <ul>
          <li>Performed by verified Vedic pandits</li>
          <li>Sankalp with your name &amp; gotra</li>
          <li>Video link of the puja sent to you</li>
          <li>Prasad shipped to your home address</li>
        </ul>
      </div>

      <div class="detail-actions">
        <a href="#book-form" class="btn btn-terra">
          Book This Puja
          <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M5 12h14M13 6l6 6-6 6"/></svg>
        </a>
        <button class="btn btn-outline" data-add-id="<?= (int) $puja['id'] ?>"
                data-add-name="<?= e($puja['name']) ?>"
                data-add-price="<?= (int) $puja['price'] ?>"
                data-add-img="<?= e(upload_url($puja['image_url'])) ?>">
          Add to Cart
        </button>
      </div>

      <div class="trust-row">
        <span class="trust-item">
          <svg viewBox="0 0 24 24"><path d="M12 2 4 6v6c0 5 3.4 8.6 8 10 4.6-1.4 8-5 8-10V6z"/><path d="m9 12 2 2 4-4"/></svg>
          Verified Priests
        </span>
        <span class="trust-item">
          <svg viewBox="0 0 24 24"><path d="M20 6 9 17l-5-5"/></svg>
          Prasad Delivery
        </span>
        <span class="trust-item">
          <svg viewBox="0 0 24 24"><circle cx="12" cy="12" r="10"/><path d="M12 6v6l4 2"/></svg>
          Video Proof
        </span>
      </div>
    </div>
  </div>

  <div class="detail-tabs">
    <button class="detail-tab active">Overview</button>
    <button class="detail-tab">Procedure</button>
    <button class="detail-tab">Reviews</button>
  </div>

  <div class="article-body" id="book-form">
    <h2>Book This Puja</h2>
    <p>Fill the form below to book <?= e($puja['name']) ?>. Our team will contact you to confirm the muhurat and date.</p>

    <?php if (is_logged_in()): ?>
    <form method="POST" style="margin-top:22px">
      <?= csrf_field() ?>
      <input type="hidden" name="action" value="puja_book">
      <input type="hidden" name="puja_id" value="<?= (int) $puja['id'] ?>">

      <div class="form-group">
        <label>Devotee Name</label>
        <input type="text" name="devotee_name" required value="<?= e(current_user_name()) ?>">
      </div>
      <div class="form-group">
        <label>Gotra (optional)</label>
        <input type="text" name="gotra" placeholder="e.g. Kashyap">
      </div>
      <div class="form-group">
        <label>Preferred Date</label>
        <input type="date" name="booking_date" required min="<?= date('Y-m-d') ?>">
      </div>
      <div class="form-group">
        <label>Sankalp / Wish (optional)</label>
        <input type="text" name="sankalp" placeholder="What do you wish to pray for?">
      </div>
      <button type="submit" class="btn btn-terra">Confirm Booking — <?= inr($puja['price']) ?></button>
    </form>
    <?php else: ?>
      <div class="flash flash-info">
        Please <a href="<?= url('login.php') ?>" style="color:var(--terracotta);font-weight:600">login</a> to book this puja.
      </div>
      <a href="<?= url('login.php') ?>" class="btn btn-terra">Login to Continue</a>
    <?php endif; ?>
  </div>
</section>

<?php require BASE_PATH . '/includes/footer.php'; ?>