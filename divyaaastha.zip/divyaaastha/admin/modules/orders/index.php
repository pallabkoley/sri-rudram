<?php
require_once dirname(__DIR__, 2) . '/includes/auth.php';

$adminPageTitle = 'Orders';
$adminPageSub   = 'All product orders';

$status = $_GET['status'] ?? '';
$where  = '1';
$params = [];

if ($status && in_array($status, ['pending','paid','packed','shipped','delivered','cancelled'], true)) {
    $where = 'o.status = ?';
    $params[] = $status;
}

$orders = [];
$stmt = $pdo->prepare(
    "SELECT o.*, u.name AS user_name, u.email
     FROM orders o LEFT JOIN users u ON u.id = o.user_id
     WHERE $where ORDER BY o.created_at DESC"
);
$stmt->execute($params);
$orders = $stmt->fetchAll();

$counts = [];
foreach (['all','pending','paid','shipped','delivered'] as $s) {
    if ($s === 'all') {
        $counts[$s] = (int) $pdo->query('SELECT COUNT(*) FROM orders')->fetchColumn();
    } else {
        $stmt = $pdo->prepare('SELECT COUNT(*) FROM orders WHERE status = ?');
        $stmt->execute([$s]);
        $counts[$s] = (int) $stmt->fetchColumn();
    }
}

require dirname(__DIR__, 2) . '/includes/header.php';
?>

<div class="admin-card">
  <div class="admin-card-head">
    <div><h3>All Orders (<?= count($orders) ?>)</h3><p>Filter by status</p></div>
  </div>

  <div style="padding:14px 22px;border-bottom:1px solid var(--line);display:flex;gap:8px;flex-wrap:wrap">
    <?php
    $tabs = [
        'all' => 'All (' . $counts['all'] . ')',
        'pending' => 'Pending (' . $counts['pending'] . ')',
        'paid' => 'Paid (' . $counts['paid'] . ')',
        'shipped' => 'Shipped (' . $counts['shipped'] . ')',
        'delivered' => 'Delivered (' . $counts['delivered'] . ')',
    ];
    foreach ($tabs as $key => $label):
        $active = ($status === $key || (!$status && $key === 'all')) ? 'btn-plum' : 'btn-outline';
    ?>
      <a href="?<?= $key === 'all' ? '' : 'status=' . $key ?>" class="btn <?= $active ?> btn-sm"><?= $label ?></a>
    <?php endforeach; ?>
  </div>

  <?php if (empty($orders)): ?>
    <div class="empty-state">
      <div class="om">📦</div>
      <h3>No orders found</h3>
    </div>
  <?php else: ?>
    <table class="admin-table">
      <thead>
        <tr>
          <?php th('Order #'); th('Customer'); th('Total'); th('Status'); th('Date'); th('', '100px'); ?>
        </tr>
      </thead>
      <tbody>
        <?php foreach ($orders as $o): ?>
          <tr>
            <td><b><?= e($o['order_number']) ?></b></td>
            <td>
              <?= e($o['user_name'] ?? $o['ship_name'] ?? 'Guest') ?><br>
              <span style="font-size:11.4px;color:var(--muted)"><?= e($o['email'] ?? $o['ship_phone'] ?? '') ?></span>
            </td>
            <td><b><?= inr($o['total']) ?></b></td>
            <td><?= status_badge($o['status']) ?></td>
            <td><?= date('d M Y', strtotime($o['created_at'])) ?></td>
            <td><a href="<?= url('admin/modules/orders/view.php?id=' . $o['id']) ?>" class="btn btn-outline btn-sm">View</a></td>
          </tr>
        <?php endforeach; ?>
      </tbody>
    </table>
  <?php endif; ?>
</div>

<?php require dirname(__DIR__, 2) . '/includes/footer.php'; ?>