<?php
require_once dirname(__DIR__, 2) . '/includes/auth.php';

$adminPageTitle = 'Settings';
$adminPageSub   = 'Site-wide configuration';

$keys = [
    'announce_text'     => 'Announcement Bar Text',
    'contact_email'     => 'Contact Email',
    'contact_phone'     => 'Contact Phone',
    'contact_address'   => 'Contact Address',
    'rating'            => 'Site Rating (e.g., 4.8)',
    'devotee_count'     => 'Devotee Count Label',
    'free_shipping_min' => 'Free Shipping Minimum',
    'social_instagram'  => 'Instagram URL',
    'social_facebook'   => 'Facebook URL',
    'social_youtube'    => 'YouTube URL',
    'social_whatsapp'   => 'WhatsApp Number (without +)',
];

if ($_SERVER['REQUEST_METHOD'] === 'POST' && csrf_verify($_POST['_token'] ?? null)) {
    foreach ($keys as $key => $label) {
        $val = trim($_POST[$key] ?? '');
        $pdo->prepare(
            'INSERT INTO settings (key_name, value) VALUES (?, ?)
             ON DUPLICATE KEY UPDATE value = VALUES(value)'
        )->execute([$key, $val]);
    }
    flash_set('success', 'Settings saved successfully.');
    redirect('admin/modules/settings/index.php');
}

$current = [];
foreach ($pdo->query('SELECT key_name, value FROM settings')->fetchAll() as $r) {
    $current[$r['key_name']] = $r['value'];
}

require dirname(__DIR__, 2) . '/includes/header.php';
?>

<div class="admin-card">
  <div class="admin-card-head">
    <div><h3>Site Settings</h3><p>Update your site-wide configuration</p></div>
  </div>
  <div class="admin-card-body">
    <form method="POST">
      <?= csrf_field() ?>
      <div class="form-grid">
        <?php foreach ($keys as $key => $label): ?>
          <div class="admin-form-group<?= $key === 'announce_text' || $key === 'contact_address' ? ' full' : '' ?>" style="<?= in_array($key, ['announce_text','contact_address']) ? 'grid-column: 1/-1;' : '' ?>">
            <label><?= e($label) ?></label>
            <input type="text" name="<?= e($key) ?>" value="<?= e($current[$key] ?? '') ?>">
          </div>
        <?php endforeach; ?>
      </div>
      <div class="form-actions">
        <button type="submit" class="btn btn-terra">Save Settings</button>
      </div>
    </form>
  </div>
</div>

<?php require dirname(__DIR__, 2) . '/includes/footer.php'; ?>