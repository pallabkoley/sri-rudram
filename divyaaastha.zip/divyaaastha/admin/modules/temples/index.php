<?php
require_once dirname(__DIR__, 2) . '/includes/auth.php';

$adminPageTitle = 'Temples';
$adminPageSub   = 'Manage all temples';

// Delete
if (isset($_GET['delete'])) {
    $id = (int) $_GET['delete'];
    $pdo->prepare('DELETE FROM temples WHERE id = ?')->execute([$id]);
    flash_set('success', 'Temple deleted successfully.');
    redirect('admin/modules/temples/index.php');
}

// Toggle active
if (isset($_GET['toggle'])) {
    $id = (int) $_GET['toggle'];
    $pdo->prepare('UPDATE temples SET is_active = 1 - is_active WHERE id = ?')->execute([$id]);
    flash_set('success', 'Temple status updated.');
    redirect('admin/modules/temples/index.php');
}

$temples = $pdo->query(
    'SELECT * FROM temples ORDER BY sort_order ASC, id DESC'
)->fetchAll();

require dirname(__DIR__, 2) . '/includes/header.php';
?>

<div class="admin-card">
  <div class="admin-card-head">
    <div>
      <h3>All Temples (<?= count($temples) ?>)</h3>
      <p>Manage sacred destinations</p>
    </div>
    <a href="<?= url('admin/modules/temples/create.php') ?>" class="btn btn-terra">+ Add Temple</a>
  </div>

  <?php if (empty($temples)): ?>
    <div class="empty-state">
      <div class="om">🛕</div>
      <h3>No temples yet</h3>
      <p>Add your first temple to get started.</p>
      <a href="<?= url('admin/modules/temples/create.php') ?>" class="btn btn-terra">+ Add Temple</a>
    </div>
  <?php else: ?>
    <table class="admin-table">
      <thead>
        <tr>
          <?php th('', '80px'); th('Name'); th('Type'); th('Location'); th('Featured'); th('Active'); th('', '180px'); ?>
        </tr>
      </thead>
      <tbody>
        <?php foreach ($temples as $t): ?>
          <tr>
            <td><?= img_tag($t['image_url'], $t['name'], 'thumb') ?></td>
            <td>
              <b><?= e($t['name']) ?></b><br>
              <span style="font-size:11.6px;color:var(--muted)"><?= e($t['slug']) ?></span>
            </td>
            <td><?= e($t['type']) ?></td>
            <td><?= e($t['city']) ?>, <?= e($t['state']) ?></td>
            <td><?= $t['is_featured'] ? '✅' : '—' ?></td>
            <td><?= active_dot((int)$t['is_active']) ?></td>
            <td>
              <div class="actions">
                <a href="<?= url('admin/modules/temples/edit.php?id=' . $t['id']) ?>">Edit</a>
                <a href="?toggle=<?= (int) $t['id'] ?>" class="act-del"><?= $t['is_active'] ? 'Disable' : 'Enable' ?></a>
                <a href="?delete=<?= (int) $t['id'] ?>"
                   data-confirm="Delete '<?= e($t['name']) ?>'?"
                   class="act-del">Del</a>
              </div>
            </td>
          </tr>
        <?php endforeach; ?>
      </tbody>
    </table>
  <?php endif; ?>
</div>

<?php require dirname(__DIR__, 2) . '/includes/footer.php'; ?>