<?php
require_once dirname(__DIR__, 2) . '/includes/auth.php';
require_once dirname(__DIR__, 2) . '/includes/functions.php';

$adminPageTitle = 'Add Temple';
$adminPageSub   = 'Create a new temple';

$errors = [];
$data = [
    'name' => '', 'slug' => '', 'type' => '', 'city' => '', 'state' => '',
    'short_desc' => '', 'description' => '', 'sort_order' => 0,
    'is_featured' => 0, 'is_dark_featured' => 0, 'is_active' => 1,
];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!csrf_verify($_POST['_token'] ?? null)) {
        $errors[] = 'Session expired.';
    } else {
        foreach ($data as $k => $v) {
            $data[$k] = trim($_POST[$k] ?? $v);
        }
        $data['is_featured']      = isset($_POST['is_featured']) ? 1 : 0;
        $data['is_dark_featured'] = isset($_POST['is_dark_featured']) ? 1 : 0;
        $data['is_active']        = isset($_POST['is_active']) ? 1 : 0;
        $data['sort_order']       = (int) ($_POST['sort_order'] ?? 0);

        if (!$data['name']) $errors[] = 'Name is required.';

        if (!$data['slug']) {
            $data['slug'] = slugify($data['name']);
        }

        if (empty($errors)) {
            // Handle image upload OR URL
            $image = trim($_POST['image_url'] ?? '');
            if (!empty($_FILES['image_file']['name'])) {
                $uploaded = admin_upload_image('image_file', 'temples');
                if ($uploaded) $image = $uploaded;
            }

            $stmt = $pdo->prepare(
                'INSERT INTO temples
                 (name, slug, type, city, state, image_url, short_desc, description,
                  is_featured, is_dark_featured, sort_order, is_active)
                 VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)'
            );
            $stmt->execute([
                $data['name'], $data['slug'], $data['type'], $data['city'], $data['state'],
                $image, $data['short_desc'], $data['description'],
                $data['is_featured'], $data['is_dark_featured'], $data['sort_order'], $data['is_active'],
            ]);

            flash_set('success', 'Temple created successfully.');
            redirect('admin/modules/temples/index.php');
        }
    }
}

require dirname(__DIR__, 2) . '/includes/header.php';
?>

<div class="admin-card">
  <div class="admin-card-head">
    <div><h3>Add New Temple</h3><p>Fill in the temple details below</p></div>
    <a href="<?= url('admin/modules/temples/index.php') ?>" class="btn btn-outline btn-sm">← Back</a>
  </div>

  <div class="admin-card-body">
    <?php if ($errors): ?>
      <div class="flash flash-error"><?= implode('<br>', array_map('e', $errors)) ?></div>
    <?php endif; ?>

    <form method="POST" enctype="multipart/form-data">
      <?= csrf_field() ?>

      <div class="form-grid">
        <div class="admin-form-group">
          <label>Name *</label>
          <input type="text" name="name" required value="<?= e($data['name']) ?>">
        </div>
        <div class="admin-form-group">
          <label>Slug (auto if blank)</label>
          <input type="text" name="slug" value="<?= e($data['slug']) ?>" placeholder="kashi-vishwanath">
        </div>
        <div class="admin-form-group">
          <label>Type</label>
          <input type="text" name="type" value="<?= e($data['type']) ?>" placeholder="Jyotirlinga, Shakti Peeth…">
        </div>
        <div class="admin-form-group">
          <label>City</label>
          <input type="text" name="city" value="<?= e($data['city']) ?>">
        </div>
        <div class="admin-form-group">
          <label>State</label>
          <input type="text" name="state" value="<?= e($data['state']) ?>">
        </div>
        <div class="admin-form-group">
          <label>Sort Order</label>
          <input type="number" name="sort_order" value="<?= (int) $data['sort_order'] ?>">
        </div>
      </div>

      <div class="admin-form-group">
        <label>Image URL (optional)</label>
        <input type="url" name="image_url" value="<?= e($data['image_url'] ?? '') ?>" placeholder="https://...">
      </div>
      <div class="admin-form-group">
        <label>Or Upload Image</label>
        <input type="file" name="image_file" accept="image/*" data-image-input="imgPrev">
        <div class="img-preview" id="imgPrev">
          <span>No image</span>
        </div>
      </div>

      <div class="admin-form-group">
        <label>Short Description</label>
        <input type="text" name="short_desc" maxlength="400" value="<?= e($data['short_desc']) ?>">
      </div>
      <div class="admin-form-group">
        <label>Full Description</label>
        <textarea name="description"><?= e($data['description']) ?></textarea>
      </div>

      <div class="form-grid">
        <div class="admin-form-group">
          <label>Featured (light carousel)</label>
          <label style="display:flex;align-items:center;gap:10px;font-weight:400;cursor:pointer">
            <input type="checkbox" name="is_featured" value="1" <?= $data['is_featured'] ? 'checked' : '' ?> style="width:auto">
            Show on homepage light section
          </label>
        </div>
        <div class="admin-form-group">
          <label>Featured (dark section)</label>
          <label style="display:flex;align-items:center;gap:10px;font-weight:400;cursor:pointer">
            <input type="checkbox" name="is_dark_featured" value="1" <?= $data['is_dark_featured'] ? 'checked' : '' ?> style="width:auto">
            Show on homepage dark section
          </label>
        </div>
      </div>

      <div class="admin-form-group">
        <label>Active</label>
        <label style="display:flex;align-items:center;gap:10px;font-weight:400;cursor:pointer">
          <input type="checkbox" name="is_active" value="1" <?= $data['is_active'] ? 'checked' : '' ?> style="width:auto">
          Publish this temple
        </label>
      </div>

      <div class="form-actions">
        <button type="submit" class="btn btn-terra">Save Temple</button>
        <a href="<?= url('admin/modules/temples/index.php') ?>" class="btn btn-outline">Cancel</a>
      </div>
    </form>
  </div>
</div>

<?php require dirname(__DIR__, 2) . '/includes/footer.php'; ?>