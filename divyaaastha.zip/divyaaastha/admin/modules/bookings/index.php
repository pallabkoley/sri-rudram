<?php
require_once dirname(__DIR__, 2) . '/includes/auth.php';

$adminPageTitle = 'Puja Bookings';
$adminPageSub   = 'All ritual bookings';

$bookings = $pdo->query(
    'SELECT b.*, p.name AS puja_name, t.name AS temple_name, u.name AS user_name
     FROM puja_bookings b
     LEFT JOIN pujas p ON p.id = b.puja_id
     LEFT JOIN temples t ON t.id = b.temple_id
     LEFT JOIN users u ON u.id = b.user_id
     ORDER BY b.created_at DESC'
)->fetchAll();

require dirname(__DIR__, 2) . '/includes/header.php';
?>

<div class="admin-card">
  <div class="admin-card-head">
    <div><h3>All Bookings (<?= count($bookings) ?>)</h3><p>Puja bookings from devotees</p></div>
  </div>

  <?php if (empty($bookings)): ?>
    <div class="empty-state">
      <div class="om">🙏</div>
      <h3>No puja bookings yet</h3>
      <p>Bookings will appear here when devotees book pujas.</p>
    </div>
  <?php else: ?>
    <table class="admin-table">
      <thead>
        <tr>
          <?php th('Ref'); th('Puja'); th('Devotee'); th('Date'); th('Amount'); th('Status'); th('', '100px'); ?>
        </tr>
      </thead>
      <tbody>
        <?php foreach ($bookings as $b): ?>
          <tr>
            <td><b><?= e($b['booking_ref']) ?></b></td>
            <td><?= e($b['puja_name'] ?? '—') ?><br><span style="font-size:11.4px;color:var(--muted)"><?= e($b['temple_name'] ?? '') ?></span></td>
            <td><?= e($b['devotee_name']) ?><?= $b['gotra'] ? '<br><span style="font-size:11.4px;color:var(--muted)">Gotra: ' . e($b['gotra']) . '</span>' : '' ?></td>
            <td><?= date('d M Y', strtotime($b['booking_date'])) ?></td>
            <td><b><?= inr($b['amount']) ?></b></td>
            <td><?= status_badge($b['status']) ?></td>
            <td><a href="<?= url('admin/modules/bookings/view.php?id=' . $b['id']) ?>" class="btn btn-outline btn-sm">View</a></td>
          </tr>
        <?php endforeach; ?>
      </tbody>
    </table>
  <?php endif; ?>
</div>

<?php require dirname(__DIR__, 2) . '/includes/footer.php'; ?>