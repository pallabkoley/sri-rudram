<?php
require_once dirname(__DIR__, 2) . '/includes/auth.php';

$adminPageTitle = 'Subscribers';
$adminPageSub   = 'Newsletter subscribers';

if (isset($_GET['delete'])) {
    $pdo->prepare('DELETE FROM subscribers WHERE id = ?')->execute([(int) $_GET['delete']]);
    flash_set('success', 'Subscriber removed.');
    redirect('admin/modules/subscribers/index.php');
}

$subs = $pdo->query('SELECT * FROM subscribers ORDER BY subscribed_at DESC')->fetchAll();

require dirname(__DIR__, 2) . '/includes/header.php';
?>

<div class="admin-card">
  <div class="admin-card-head">
    <div><h3>Subscribers (<?= count($subs) ?>)</h3><p>People who subscribed to updates</p></div>
    <?php if (!empty($subs)): ?>
      <a href="<?= url('admin/modules/subscribers/export.php') ?>" class="btn btn-terra btn-sm">⬇ Export CSV</a>
    <?php endif; ?>
  </div>

  <?php if (empty($subs)): ?>
    <div class="empty-state">
      <div class="om">📧</div>
      <h3>No subscribers yet</h3>
    </div>
  <?php else: ?>
    <table class="admin-table">
      <thead>
        <tr><?php th('Email'); th('Status'); th('Subscribed'); th('', '100px'); ?></tr>
      </thead>
      <tbody>
        <?php foreach ($subs as $s): ?>
          <tr>
            <td><b><?= e($s['email']) ?></b></td>
            <td><?= status_badge($s['status'] === 'active' ? 'paid' : 'cancelled') ?></td>
            <td><?= date('d M Y', strtotime($s['subscribed_at'])) ?></td>
            <td><a href="?delete=<?= (int) $s['id'] ?>" data-confirm="Remove this subscriber?" class="btn btn-outline btn-sm">Remove</a></td>
          </tr>
        <?php endforeach; ?>
      </tbody>
    </table>
  <?php endif; ?>
</div>

<?php require dirname(__DIR__, 2) . '/includes/footer.php'; ?>