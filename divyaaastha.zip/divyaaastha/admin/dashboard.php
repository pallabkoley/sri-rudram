<?php
require_once __DIR__ . '/includes/auth.php';

$adminPageTitle = 'Dashboard';
$adminPageSub   = "Welcome back, here's what's happening today";

// Stats
$stats = [
    'orders'    => (int) $pdo->query('SELECT COUNT(*) FROM orders')->fetchColumn(),
    'bookings'  => (int) $pdo->query('SELECT COUNT(*) FROM puja_bookings')->fetchColumn(),
    'products'  => (int) $pdo->query('SELECT COUNT(*) FROM products WHERE is_active = 1')->fetchColumn(),
    'users'     => (int) $pdo->query('SELECT COUNT(*) FROM users WHERE role = "devotee"')->fetchColumn(),
    'revenue'   => (float) $pdo->query('SELECT COALESCE(SUM(total), 0) FROM orders WHERE status IN ("paid","packed","shipped","delivered")')->fetchColumn(),
    'pending'   => (int) $pdo->query('SELECT COUNT(*) FROM orders WHERE status = "pending"')->fetchColumn(),
    'temples'   => (int) $pdo->query('SELECT COUNT(*) FROM temples WHERE is_active = 1')->fetchColumn(),
    'pujas'     => (int) $pdo->query('SELECT COUNT(*) FROM pujas WHERE is_active = 1')->fetchColumn(),
];

$recentOrders = $pdo->query(
    'SELECT o.id, o.order_number, o.total, o.status, o.created_at, u.name AS user_name
     FROM orders o LEFT JOIN users u ON u.id = o.user_id
     ORDER BY o.created_at DESC LIMIT 5'
)->fetchAll();

$recentBookings = $pdo->query(
    'SELECT b.id, b.booking_ref, b.amount, b.status, b.booking_date, b.devotee_name, p.name AS puja_name
     FROM puja_bookings b LEFT JOIN pujas p ON p.id = b.puja_id
     ORDER BY b.created_at DESC LIMIT 5'
)->fetchAll();

require __DIR__ . '/includes/header.php';
?>

<!-- Stats Grid -->
<div class="row g-3 mb-4">
  <div class="col-xl-3 col-md-6">
    <div class="stat-card">
      <div class="stat-label">
        Revenue
        <span class="stat-icon"><i class="bi bi-currency-rupee"></i></span>
      </div>
      <div class="stat-value"><?= inr($stats['revenue']) ?></div>
      <div class="stat-foot">From paid & delivered orders</div>
    </div>
  </div>

  <div class="col-xl-3 col-md-6">
    <div class="stat-card">
      <div class="stat-label">
        Total Orders
        <span class="stat-icon gold"><i class="bi bi-box-seam"></i></span>
      </div>
      <div class="stat-value"><?= $stats['orders'] ?></div>
      <div class="stat-foot"><?= $stats['pending'] ?> pending</div>
    </div>
  </div>

  <div class="col-xl-3 col-md-6">
    <div class="stat-card">
      <div class="stat-label">
        Puja Bookings
        <span class="stat-icon plum"><i class="bi bi-calendar-check"></i></span>
      </div>
      <div class="stat-value"><?= $stats['bookings'] ?></div>
      <div class="stat-foot">All-time bookings</div>
    </div>
  </div>

  <div class="col-xl-3 col-md-6">
    <div class="stat-card">
      <div class="stat-label">
        Devotees
        <span class="stat-icon sage"><i class="bi bi-people"></i></span>
      </div>
      <div class="stat-value"><?= $stats['users'] ?></div>
      <div class="stat-foot"><?= $stats['temples'] ?> temples · <?= $stats['pujas'] ?> pujas</div>
    </div>
  </div>
</div>

<!-- Recent Orders -->
<div class="row g-3 mb-4">
  <div class="col-lg-7">
    <div class="card h-100">
      <div class="card-header-clean">
        <div>
          <h3>Recent Orders</h3>
          <p>Latest product purchases</p>
        </div>
        <a href="<?= url('admin/modules/orders/index.php') ?>" class="btn-outline-brand">
          View All <i class="bi bi-arrow-right"></i>
        </a>
      </div>

      <?php if (empty($recentOrders)): ?>
        <div class="empty-state">
          <div class="om"><i class="bi bi-box"></i></div>
          <h3>No orders yet</h3>
          <p>Orders will appear here once devotees start purchasing.</p>
        </div>
      <?php else: ?>
        <div class="table-responsive">
          <table class="admin-table">
            <thead>
              <tr>
                <th>Order #</th>
                <th>Devotee</th>
                <th>Total</th>
                <th>Status</th>
                <th>Date</th>
              </tr>
            </thead>
            <tbody>
              <?php foreach ($recentOrders as $o): ?>
                <tr>
                  <td><b><?= e($o['order_number']) ?></b></td>
                  <td><?= e($o['user_name'] ?? 'Guest') ?></td>
                  <td><b><?= inr($o['total']) ?></b></td>
                  <td><span class="status-badge status-<?= e($o['status']) ?>"><?= e($o['status']) ?></span></td>
                  <td><?= date('d M', strtotime($o['created_at'])) ?></td>
                </tr>
              <?php endforeach; ?>
            </tbody>
          </table>
        </div>
      <?php endif; ?>
    </div>
  </div>

  <div class="col-lg-5">
    <div class="card h-100">
      <div class="card-header-clean">
        <div>
          <h3>Recent Puja Bookings</h3>
          <p>Latest ritual bookings</p>
        </div>
        <a href="<?= url('admin/modules/bookings/index.php') ?>" class="btn-outline-brand">
          View All <i class="bi bi-arrow-right"></i>
        </a>
      </div>

      <?php if (empty($recentBookings)): ?>
        <div class="empty-state">
          <div class="om"><i class="bi bi-flower1"></i></div>
          <h3>No bookings yet</h3>
          <p>Puja bookings will appear here.</p>
        </div>
      <?php else: ?>
        <div class="table-responsive">
          <table class="admin-table">
            <thead>
              <tr>
                <th>Ref</th>
                <th>Puja</th>
                <th>Amount</th>
                <th>Status</th>
              </tr>
            </thead>
            <tbody>
              <?php foreach ($recentBookings as $b): ?>
                <tr>
                  <td><b><?= e($b['booking_ref']) ?></b></td>
                  <td><?= e($b['puja_name'] ?? '—') ?></td>
                  <td><b><?= inr($b['amount']) ?></b></td>
                  <td><span class="status-badge status-<?= e($b['status']) ?>"><?= e($b['status']) ?></span></td>
                </tr>
              <?php endforeach; ?>
            </tbody>
          </table>
        </div>
      <?php endif; ?>
    </div>
  </div>
</div>

<!-- Quick Actions -->
<div class="card">
  <div class="card-header-clean">
    <div><h3>Quick Actions</h3><p>Common admin tasks</p></div>
  </div>
  <div class="card-body-clean">
    <div class="row g-3">
      <div class="col-lg-3 col-md-6">
        <a href="<?= url('admin/modules/temples/create.php') ?>" class="btn btn-outline-brand w-100 py-3">
          <i class="bi bi-plus-circle"></i> Add Temple
        </a>
      </div>
      <div class="col-lg-3 col-md-6">
        <a href="<?= url('admin/modules/pujas/create.php') ?>" class="btn btn-outline-brand w-100 py-3">
          <i class="bi bi-plus-circle"></i> Add Puja
        </a>
      </div>
      <div class="col-lg-3 col-md-6">
        <a href="<?= url('admin/modules/products/create.php') ?>" class="btn btn-outline-brand w-100 py-3">
          <i class="bi bi-plus-circle"></i> Add Product
        </a>
      </div>
      <div class="col-lg-3 col-md-6">
        <a href="<?= url('admin/modules/articles/create.php') ?>" class="btn btn-outline-brand w-100 py-3">
          <i class="bi bi-plus-circle"></i> Add Article
        </a>
      </div>
    </div>
  </div>
</div>

<?php require __DIR__ . '/includes/footer.php'; ?>