    </div><!-- /.content-area -->
</div><!-- /.main-content -->

<!-- Bootstrap JS -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
<script src="<?= asset('admin/assets/js/admin.js') ?>" defer></script>

</body>
</html>