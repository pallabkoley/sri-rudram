<?php
// admin/includes/functions.php

/** Upload an image and return relative path */
function admin_upload_image(string $field, string $subfolder, ?string $existing = null): ?string
{
    if (empty($_FILES[$field]['name'])) return $existing;

    $file = $_FILES[$field];
    if ($file['error'] !== UPLOAD_ERR_OK) return $existing;

    $allowed = ['jpg','jpeg','png','webp','gif'];
    $ext = strtolower(pathinfo($file['name'], PATHINFO_EXTENSION));

    if (!in_array($ext, $allowed, true)) {
        flash_set('error', 'Invalid image type. Allowed: jpg, png, webp, gif.');
        return $existing;
    }
    if ($file['size'] > 5 * 1024 * 1024) {
        flash_set('error', 'Image too large (max 5MB).');
        return $existing;
    }

    $dir = UPLOAD_PATH . '/' . $subfolder;
    if (!is_dir($dir)) mkdir($dir, 0755, true);

    $name = uniqid('img_', true) . '.' . $ext;
    $dest = $dir . '/' . $name;

    if (!move_uploaded_file($file['tmp_name'], $dest)) {
        flash_set('error', 'Upload failed.');
        return $existing;
    }

    return $subfolder . '/' . $name;
}

/** Admin table head cell */
function th(string $label, string $width = ''): void
{
    echo '<th' . ($width ? ' style="width:' . $width . '"' : '') . '>' . e($label) . '</th>';
}

/** Status badge */
function status_badge(string $status): string
{
    return '<span class="badge-status badge-' . e($status) . '">' . e(ucfirst($status)) . '</span>';
}

/** Active toggle badge */
function active_dot(int $active): string
{
    return $active
        ? '<span class="dot-active" title="Active"></span>'
        : '<span class="dot-inactive" title="Inactive"></span>';
}

/** Pagination links */
function admin_pagination(int $total, int $perPage, int $currentPage, string $baseUrl): void
{
    $pages = (int) ceil($total / $perPage);
    if ($pages <= 1) return;

    echo '<div class="pagination">';
    for ($i = 1; $i <= $pages; $i++) {
        $sep = str_contains($baseUrl, '?') ? '&' : '?';
        $cls = $i === $currentPage ? ' active' : '';
        echo '<a href="' . e($baseUrl . $sep . 'page=' . $i) . '" class="pg-btn' . $cls . '">' . $i . '</a>';
    }
    echo '</div>';
}