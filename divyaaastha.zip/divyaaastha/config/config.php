<?php
// config/config.php
declare(strict_types=1);

// ─── Load .env ───
$envFile = dirname(__DIR__) . '/.env';
if (is_file($envFile)) {
    foreach (file($envFile, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES) as $line) {
        $line = trim($line);
        if ($line === '' || str_starts_with($line, '#')) continue;
        [$k, $v] = array_pad(explode('=', $line, 2), 2, '');
        $_ENV[trim($k)] = trim($v, " \t\n\r\0\x0B\"'");
    }
}

// ─── Constants ───
define('BASE_PATH',   dirname(__DIR__));
define('APP_NAME',    $_ENV['APP_NAME']  ?? 'Divya Aastha');
define('APP_URL',     rtrim($_ENV['APP_URL'] ?? 'http://localhost/divyaaastha', '/'));
define('APP_ENV',     $_ENV['APP_ENV']   ?? 'production');
define('APP_DEBUG',   filter_var($_ENV['APP_DEBUG'] ?? false, FILTER_VALIDATE_BOOL));
define('UPLOAD_PATH', BASE_PATH . '/uploads');
define('UPLOAD_URL',  APP_URL . '/uploads');

date_default_timezone_set('Asia/Kolkata');

// ─── Errors ───
if (APP_DEBUG) {
    ini_set('display_errors', '1');
    error_reporting(E_ALL);
} else {
    ini_set('display_errors', '0');
    ini_set('log_errors', '1');
    ini_set('error_log', BASE_PATH . '/storage/logs/error.log');
}

// ─── Session ───
if (session_status() === PHP_SESSION_NONE) {
    session_set_cookie_params([
        'httponly' => true,
        'samesite' => 'Lax',
        'secure'   => isset($_SERVER['HTTPS']),
    ]);
    session_start();
}

// ─── Core includes ───
require_once BASE_PATH . '/config/db.php';
require_once BASE_PATH . '/includes/functions.php';
require_once BASE_PATH . '/includes/db-queries.php';
require_once BASE_PATH . '/includes/auth.php';