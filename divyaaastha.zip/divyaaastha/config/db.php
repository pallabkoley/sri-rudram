<?php
// config/db.php
$DB_HOST    = $_ENV['DB_HOST'] ?? '127.0.0.1';
$DB_PORT    = $_ENV['DB_PORT'] ?? '3306';
$DB_NAME    = $_ENV['DB_NAME'] ?? 'divyaaastha';
$DB_USER    = $_ENV['DB_USER'] ?? 'root';
$DB_PASS    = $_ENV['DB_PASS'] ?? '';
$DB_CHARSET = 'utf8mb4';

$dsn = "mysql:host={$DB_HOST};port={$DB_PORT};dbname={$DB_NAME};charset={$DB_CHARSET}";

try {
    $pdo = new PDO($dsn, $DB_USER, $DB_PASS, [
        PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
        PDO::ATTR_EMULATE_PREPARES   => false,
    ]);
} catch (PDOException $e) {
    error_log('DB Connection failed: ' . $e->getMessage());
    http_response_code(500);
    exit(APP_DEBUG ? 'DB Error: ' . $e->getMessage() : 'Service temporarily unavailable.');
}