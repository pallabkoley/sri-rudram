<?php
require_once __DIR__ . '/config/config.php';
$articles = get_featured_articles(24);
$categories = $pdo->query('SELECT * FROM article_categories ORDER BY sort_order ASC')->fetchAll();

$pageTitle = 'Dharmik Gyan — Articles, Mantras & Rituals';
$pageDesc  = 'Deeply researched articles on rituals, mantras and Hindu philosophy.';
require BASE_PATH . '/includes/header.php';
?>

<section class="page-hero">
  <div class="page-hero-mandala"></div>
  <div class="container">
    <nav class="breadcrumb">
      <a href="<?= url('index.php') ?>">Home</a>
      <span class="sep">›</span>
      <span class="current">Gyan</span>
    </nav>
    <span class="eyebrow">Dharmik Gyan</span>
    <h1>Read, Learn &amp; Grow</h1>
    <p>Deeply researched articles on rituals, mantras and Hindu philosophy.</p>
  </div>
</section>

<section class="section">
  <div class="container">
    <div class="filter-bar">
      <a href="<?= url('gyan.php') ?>" class="filter-chip active">All Articles</a>
      <?php foreach ($categories as $c): ?>
        <a href="<?= url('gyan.php?cat=' . $c['slug']) ?>" class="filter-chip"><?= e($c['name']) ?></a>
      <?php endforeach; ?>
      <span class="filter-count"><?= count($articles) ?> articles</span>
    </div>

    <div class="article-grid">
      <?php foreach ($articles as $a): ?>
        <article class="article-card reveal">
          <div class="ar-media">
            <?= img_tag($a['image_url'], $a['title']) ?>
            <span class="ar-cat"><?= e($a['category_name'] ?? 'Gyan') ?></span>
          </div>
          <div class="ar-body">
            <h3><a href="<?= url('article.php?slug=' . $a['slug']) ?>"><?= e($a['title']) ?></a></h3>
            <p><?= e($a['excerpt']) ?></p>
            <div class="ar-meta">
              <span><?= (int) $a['read_minutes'] ?> min read</span>
              <span class="dot" style="width:3px;height:3px;border-radius:50%;background:var(--sand-3);display:inline-block"></span>
              <span><?= $a['published_at'] ? date('d M Y', strtotime($a['published_at'])) : '' ?></span>
            </div>
            <a href="<?= url('article.php?slug=' . $a['slug']) ?>" class="btn-ghost">Read Article →</a>
          </div>
        </article>
      <?php endforeach; ?>
    </div>
  </div>
</section>

<?php require BASE_PATH . '/includes/footer.php'; ?>