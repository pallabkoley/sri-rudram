<?php
require_once __DIR__ . '/config/config.php';
$pageTitle = 'Rashifal — Daily Horoscope';
require BASE_PATH . '/includes/header.php';
?>

<section class="page-hero">
  <div class="page-hero-mandala"></div>
  <div class="container">
    <nav class="breadcrumb">
      <a href="<?= url('index.php') ?>">Home</a>
      <span class="sep">›</span>
      <span class="current">Rashifal</span>
    </nav>
    <span class="eyebrow">Vedic Astrology</span>
    <h1>Today's Rashifal</h1>
    <p>Daily horoscope for all 12 zodiac signs.</p>
  </div>
</section>

<section class="section">
  <div class="container">
    <div class="coming-soon">
      <div class="om">✨</div>
      <h2>Rashifal Coming Soon</h2>
      <p>We are integrating live astrological predictions for all 12 rashi signs — Mesh, Vrishabh, Mithun, Kark, Simha, Kanya, Tula, Vrishchik, Dhanu, Makar, Kumbh, Meen.</p>
      <a href="<?= url('index.php') ?>" class="btn btn-outline">Back to Home</a>
    </div>
  </div>
</section>

<?php require BASE_PATH . '/includes/footer.php'; ?>