<?php
require_once __DIR__ . '/config/config.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action'])) {
    require BASE_PATH . '/includes/handlers/cart-handler.php';
}

require_login();

$stmt = $pdo->prepare(
    'SELECT b.*, p.name AS puja_name, p.slug AS puja_slug, t.name AS temple_name
     FROM puja_bookings b
     LEFT JOIN pujas p ON p.id = b.puja_id
     LEFT JOIN temples t ON t.id = b.temple_id
     WHERE b.user_id = ? ORDER BY b.created_at DESC'
);
$stmt->execute([current_user_id()]);
$bookings = $stmt->fetchAll();

$pageTitle = 'My Puja Bookings — ' . APP_NAME;
require BASE_PATH . '/includes/header.php';
?>

<section class="page-hero">
  <div class="page-hero-mandala"></div>
  <div class="container">
    <nav class="breadcrumb">
      <a href="<?= url('index.php') ?>">Home</a>
      <span class="sep">›</span>
      <a href="<?= url('account.php') ?>">Account</a>
      <span class="sep">›</span>
      <span class="current">Bookings</span>
    </nav>
    <h1>My Puja Bookings</h1>
  </div>
</section>

<section class="section">
  <div class="container">
    <div class="account-grid">
      <aside class="account-nav">
        <a href="<?= url('account.php') ?>">👤 Dashboard</a>
        <a href="<?= url('account-orders.php') ?>">📦 My Orders</a>
        <a href="<?= url('account-bookings.php') ?>" class="active">🙏 My Bookings</a>
        <a href="<?= url('wishlist.php') ?>">♡ Wishlist</a>
        <a href="<?= url('logout.php') ?>">🚪 Logout</a>
      </aside>

      <div class="account-main">
        <h1>Puja Bookings</h1>
        <p class="sub"><?= count($bookings) ?> booking<?= count($bookings) === 1 ? '' : 's' ?> found</p>

        <?php if (empty($bookings)): ?>
          <div class="cart-empty" style="padding:60px 30px">
            <div class="om" style="font-size:42px">🙏</div>
            <h3>No puja bookings yet</h3>
            <p>Book your first puja at a sacred temple.</p>
            <a href="<?= url('pujas.php') ?>" class="btn btn-terra">Browse Pujas</a>
          </div>
        <?php else: ?>
          <?php foreach ($bookings as $b): ?>
            <div class="order-card">
              <div class="order-card-head">
                <b><?= e($b['puja_name']) ?></b>
                <span class="order-status <?= e($b['status']) ?>"><?= e($b['status']) ?></span>
              </div>
              <div style="font-size:12.8px;color:var(--muted);line-height:1.9">
                <div><strong style="color:var(--plum)">Reference:</strong> <?= e($b['booking_ref']) ?></div>
                <?php if (!empty($b['temple_name'])): ?>
                  <div><strong style="color:var(--plum)">Temple:</strong> <?= e($b['temple_name']) ?></div>
                <?php endif; ?>
                <div><strong style="color:var(--plum)">Date:</strong> <?= date('d M Y', strtotime($b['booking_date'])) ?></div>
                <div><strong style="color:var(--plum)">Amount:</strong> <?= inr($b['amount']) ?></div>
              </div>
            </div>
          <?php endforeach; ?>
        <?php endif; ?>
      </div>
    </div>
  </div>
</section>

<?php require BASE_PATH . '/includes/footer.php'; ?>