<?php
require_once __DIR__ . '/config/config.php';
$slug = $_GET['slug'] ?? '';
$article = get_article_by_slug($slug);

if (!$article) { http_response_code(404); require BASE_PATH . '/404.php'; exit; }

$pageTitle = $article['title'];
$pageDesc  = $article['excerpt'];
require BASE_PATH . '/includes/header.php';
?>

<section class="page-hero">
  <div class="page-hero-mandala"></div>
  <div class="container">
    <nav class="breadcrumb">
      <a href="<?= url('index.php') ?>">Home</a>
      <span class="sep">›</span>
      <a href="<?= url('gyan.php') ?>">Gyan</a>
      <span class="sep">›</span>
      <span class="current"><?= e($article['category_name'] ?? 'Article') ?></span>
    </nav>
    <span class="eyebrow"><?= e($article['category_name'] ?? 'Gyan') ?></span>
    <h1 style="max-width:820px"><?= e($article['title']) ?></h1>
    <div class="detail-meta" style="margin-top:16px">
      <span class="m-item">📅 <?= date('d M Y', strtotime($article['published_at'])) ?></span>
      <span class="m-item">⏱ <?= (int) $article['read_minutes'] ?> min read</span>
    </div>
  </div>
</section>

<article class="container">
  <div class="detail-media" style="aspect-ratio:16/8;margin-top:40px;border-radius:var(--r-lg)">
    <?= img_tag($article['image_url'], $article['title'], '', false) ?>
  </div>

  <div class="article-body">
    <?php if (!empty($article['excerpt'])): ?>
      <blockquote><?= e($article['excerpt']) ?></blockquote>
    <?php endif; ?>
    <?= $article['body'] ?: '<p>Full article coming soon.</p>' ?>
  </div>

  <div class="center-cta">
    <a href="<?= url('gyan.php') ?>" class="btn btn-outline">← Back to Gyan</a>
  </div>
</article>

<?php require BASE_PATH . '/includes/footer.php'; ?>