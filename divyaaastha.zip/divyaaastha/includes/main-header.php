<?php
$nav = [
    ['label' => 'Home',            'href' => 'index.php'],
    ['label' => 'Puja',            'href' => 'pujas.php'],
    ['label' => 'Shop',            'href' => 'shop.php'],
    ['label' => 'Panchang',        'href' => 'panchang.php'],
    ['label' => 'Rashifal',        'href' => 'rashifal.php'],
    ['label' => 'Gyan',            'href' => 'gyan.php'],
    ['label' => 'Spiritual Store', 'href' => 'shop.php'],
];
$current = current_page();
?>
<header class="site-header" id="siteHeader">
  <div class="container header-inner">
    <a href="<?= url('index.php') ?>" class="brand">
      <span class="brand-mark">ॐ</span>
      <span class="brand-text"><strong>Divya</strong><em>Aastha</em></span>
    </a>

    <nav class="main-nav" aria-label="Primary">
      <?php foreach ($nav as $item): ?>
        <a href="<?= url($item['href']) ?>" class="nav-link<?= $current === $item['href'] ? ' active' : '' ?>">
          <?= e($item['label']) ?>
        </a>
      <?php endforeach; ?>
    </nav>

    <div class="header-actions">
      <button class="icon-btn" id="searchBtn" aria-label="Search">
        <svg viewBox="0 0 24 24"><circle cx="11" cy="11" r="7"/><path d="M20 20l-3.5-3.5"/></svg>
      </button>

      <a href="<?= url('wishlist.php') ?>" class="icon-btn" aria-label="Wishlist">
        <svg viewBox="0 0 24 24"><path d="M20.8 4.6a5.5 5.5 0 0 0-7.8 0L12 5.7l-1-1.1a5.5 5.5 0 0 0-7.8 7.8l1.1 1L12 21l7.7-7.6 1.1-1a5.5 5.5 0 0 0 0-7.8z"/></svg>
        <span class="badge" id="wishCount"><?= $wishCount ?></span>
      </a>

      <button class="icon-btn" id="cartBtn" aria-label="Cart">
        <svg viewBox="0 0 24 24"><path d="M6 2 3 6v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2V6l-3-4z"/><path d="M3 6h18"/><path d="M16 10a4 4 0 0 1-8 0"/></svg>
        <span class="badge" id="cartCount"><?= $cartCount ?></span>
      </button>

      <div class="account-wrap">
        <button class="icon-btn" id="accountBtn" aria-label="Account" aria-expanded="false">
          <svg viewBox="0 0 24 24"><circle cx="12" cy="8" r="4"/><path d="M4 21a8 8 0 0 1 16 0"/></svg>
        </button>
        <div class="account-menu" id="accountMenu" role="menu">
          <?php if (is_logged_in()): ?>
            <div class="am-head">
              <b>Namaste, <?= e(current_user_name()) ?></b>
              <span>Welcome back</span>
            </div>
            <a href="<?= url('account.php') ?>">My Account</a>
            <a href="<?= url('account-orders.php') ?>">My Orders</a>
            <a href="<?= url('account-bookings.php') ?>">My Bookings</a>
            <a href="<?= url('wishlist.php') ?>">Wishlist</a>
            <div class="am-sep"></div>
            <a href="<?= url('logout.php') ?>">Logout</a>
          <?php else: ?>
            <div class="am-head">
              <b>Namaste, Devotee</b>
              <span>Welcome to <?= e(APP_NAME) ?></span>
            </div>
            <a href="<?= url('login.php') ?>">Login</a>
            <a href="<?= url('register.php') ?>">Register</a>
          <?php endif; ?>
        </div>
      </div>

      <a href="<?= url('pujas.php') ?>" class="btn header-cta">Book Puja</a>

      <button class="icon-btn hamburger" id="hamburgerBtn" aria-label="Menu">
        <svg viewBox="0 0 24 24"><path d="M3 6h18M3 12h18M3 18h18"/></svg>
      </button>
    </div>
  </div>
</header>