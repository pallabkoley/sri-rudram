<?php
// includes/auth.php

function is_logged_in(): bool {
    return !empty($_SESSION['user_id']);
}

function current_user_id(): ?int {
    return isset($_SESSION['user_id']) ? (int) $_SESSION['user_id'] : null;
}

function current_user_name(): string {
    return $_SESSION['user_name'] ?? 'Devotee';
}

function current_user(): ?array {
    if (!is_logged_in()) return null;
    global $pdo;
    static $cache = null;
    if ($cache === null) {
        $stmt = $pdo->prepare('SELECT id, name, email, phone, gotra, role FROM users WHERE id = ? AND status = 1 LIMIT 1');
        $stmt->execute([$_SESSION['user_id']]);
        $cache = $stmt->fetch() ?: null;
    }
    return $cache;
}

function is_admin(): bool {
    return ($_SESSION['user_role'] ?? '') === 'admin';
}

function require_login(): void {
    if (!is_logged_in()) {
        $_SESSION['redirect_after_login'] = $_SERVER['REQUEST_URI'] ?? '/';
        flash_set('info', 'Please login to continue.');
        redirect('login.php');
    }
}

function login_user(array $user): void {
    $_SESSION['user_id']   = (int) $user['id'];
    $_SESSION['user_name'] = $user['name'];
    $_SESSION['user_role'] = $user['role'];
    session_regenerate_id(true);
}

function logout_user(): void {
    unset($_SESSION['user_id'], $_SESSION['user_name'], $_SESSION['user_role']);
    session_regenerate_id(true);
}