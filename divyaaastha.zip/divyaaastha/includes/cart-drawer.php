<?php $__cartItems = cart_items($cartId); ?>
<div class="drawer-backdrop" id="drawerBackdrop"></div>
<aside class="cart-drawer" id="cartDrawer" role="dialog" aria-label="Shopping cart" aria-hidden="true">
  <div class="cd-head">
    <h3>Your Cart <span id="cartHeadCount"><?= $cartCount ?> item<?= $cartCount === 1 ? '' : 's' ?></span></h3>
    <button class="cd-close" id="cartClose" aria-label="Close">
      <svg viewBox="0 0 24 24"><path d="M18 6 6 18M6 6l12 12"/></svg>
    </button>
  </div>

  <div class="cd-body" id="cartBody">
    <?php if (empty($__cartItems)): ?>
      <div class="cd-empty">
        <div class="om">ॐ</div>
        <h4>Your cart is empty</h4>
        <p>Add sacred essentials to begin your journey.</p>
        <a href="<?= url('shop.php') ?>" class="btn btn-plum btn-sm">Explore Siddha Store</a>
      </div>
    <?php else: ?>
      <?php foreach ($__cartItems as $item): ?>
        <div class="cd-item" data-id="<?= (int) $item['id'] ?>">
          <?= img_tag($item['image_url'], $item['name']) ?>
          <div class="cd-info">
            <h4><?= e($item['name']) ?></h4>
            <div class="cd-price"><?= inr($item['price']) ?></div>
            <div class="qty">
              <button data-act="dec">−</button>
              <span><?= (int) $item['qty'] ?></span>
              <button data-act="inc">+</button>
            </div>
          </div>
          <button class="cd-remove" data-act="remove" aria-label="Remove">
            <svg viewBox="0 0 24 24"><path d="M18 6 6 18M6 6l12 12"/></svg>
          </button>
        </div>
      <?php endforeach; ?>
    <?php endif; ?>
  </div>

  <div class="cd-foot" id="cartFoot" <?= empty($__cartItems) ? 'style="display:none"' : '' ?>>
    <div class="cd-row"><span>Subtotal</span><span id="cartSubtotal"><?= inr(cart_subtotal($cartId)) ?></span></div>
    <div class="cd-row"><span>Shipping</span><span style="color:var(--muted-sage);font-weight:600">Complimentary</span></div>
    <div class="cd-row total"><span>Total</span><span id="cartTotal"><?= inr(cart_subtotal($cartId)) ?></span></div>
    <div class="cd-actions">
      <a href="<?= url('cart.php') ?>" class="btn btn-outline btn-sm">View Cart</a>
      <a href="<?= url('checkout.php') ?>" class="btn btn-plum btn-sm">Checkout</a>
    </div>
  </div>
</aside>