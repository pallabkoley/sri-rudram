<?php
$cartId     = cart_current_id();
$cartCount  = cart_qty($cartId);
$wishCount  = wishlist_count();
$currentUri = $_SERVER['REQUEST_URI'] ?? '/';
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title><?= e($pageTitle ?? APP_NAME . ' — Puja Booking, Siddha Store & Dharmik Gyan') ?></title>
<meta name="description" content="<?= e($pageDesc ?? 'Book authentic Hindu pujas, receive sacred prasad at home, shop rudraksha & consecrated tools.') ?>">

<meta property="og:title" content="<?= e($pageTitle ?? APP_NAME) ?>">
<meta property="og:description" content="<?= e($pageDesc ?? '') ?>">
<meta property="og:type" content="website">
<meta property="og:url" content="<?= e(url($currentUri)) ?>">
<meta name="twitter:card" content="summary_large_image">
<meta name="theme-color" content="#351B2F">

<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&family=Playfair+Display:ital,wght@0,400;0,500;0,600;0,700;0,800;1,400;1,500&display=swap" rel="stylesheet">
<link rel="stylesheet" href="<?= asset('assets/css/app.css') ?>">

<script>
window.APP_URL = <?= json_encode(APP_URL) ?>;
window.CSRF_TOKEN = <?= json_encode(csrf_token()) ?>;
</script>
</head>
<body data-csrf="<?= e(csrf_token()) ?>">

<?php require BASE_PATH . '/includes/announce.php'; ?>
<?php require BASE_PATH . '/includes/main-header.php'; ?>
<?php require BASE_PATH . '/includes/mobile-nav.php'; ?>
<?php require BASE_PATH . '/includes/search-overlay.php'; ?>
<?php require BASE_PATH . '/includes/cart-drawer.php'; ?>

<main>