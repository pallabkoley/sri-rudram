<?php
// includes/functions.php

/** HTML escape */
function e(?string $v): string {
    return htmlspecialchars((string) $v, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8');
}

/** ₹ Indian currency format */
function inr(float|int|string $n): string {
    return '₹' . number_format((float) $n, 0, '.', ',');
}

/** Absolute URL */
function url(string $path = ''): string {
    return APP_URL . '/' . ltrim($path, '/');
}

/** Cache-busted asset URL */
function asset(string $path): string {
    $full = BASE_PATH . '/' . ltrim($path, '/');
    $ver  = is_file($full) ? filemtime($full) : time();
    return url($path) . '?v=' . $ver;
}

/** Upload URL for user-uploaded images */
function upload_url(?string $file, string $fallback = 'assets/img/placeholder.php'): string {
    if (!$file) return url($fallback);
    if (str_starts_with($file, 'http')) return $file;
    return UPLOAD_URL . '/' . ltrim($file, '/');
}

/** <img> tag with fallback */
function img_tag(?string $src, string $alt = '', string $class = '', bool $lazy = true): string {
    $url      = upload_url($src);
    $lazyAttr = $lazy ? ' loading="lazy" decoding="async"' : ' fetchpriority="high"';
    $clsAttr  = $class !== '' ? ' class="' . e($class) . '"' : '';
    return sprintf(
        '<img src="%s" alt="%s"%s%s onerror="this.onerror=null;this.src=\'%s\'">',
        e($url), e($alt), $clsAttr, $lazyAttr, url('assets/img/placeholder.php')
    );
}

/* ═══════════════ CSRF ═══════════════ */
function csrf_token(): string {
    if (empty($_SESSION['_csrf'])) {
        $_SESSION['_csrf'] = bin2hex(random_bytes(32));
    }
    return $_SESSION['_csrf'];
}

function csrf_field(): string {
    return '<input type="hidden" name="_token" value="' . e(csrf_token()) . '">';
}

function csrf_verify(?string $token): bool {
    return is_string($token)
        && !empty($_SESSION['_csrf'])
        && hash_equals($_SESSION['_csrf'], $token);
}

/* ═══════════════ Flash ═══════════════ */
function flash_set(string $type, string $msg): void {
    $_SESSION['_flash'][] = ['type' => $type, 'msg' => $msg];
}

function flash_get(): array {
    $f = $_SESSION['_flash'] ?? [];
    unset($_SESSION['_flash']);
    return $f;
}

/* ═══════════════ Input ═══════════════ */
function post(string $key, mixed $default = null): mixed {
    return $_POST[$key] ?? $default;
}

function get(string $key, mixed $default = null): mixed {
    return $_GET[$key] ?? $default;
}

/** JSON response */
function json_out(mixed $data, int $status = 200): never {
    http_response_code($status);
    header('Content-Type: application/json; charset=utf-8');
    echo json_encode($data, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    exit;
}

/** Redirect */
function redirect(string $path): never {
    header('Location: ' . (str_starts_with($path, 'http') ? $path : url($path)));
    exit;
}

/** Slug from title */
function slugify(string $text): string {
    $text = strtolower(trim($text));
    $text = preg_replace('/[^a-z0-9]+/', '-', $text);
    return trim($text, '-');
}

/** Pagination helper — returns [perPage, offset, page] */
function paginate(int $perPage = 20): array {
    $page   = max(1, (int) ($_GET['page'] ?? 1));
    $offset = ($page - 1) * $perPage;
    return [$perPage, $offset, $page];
}

/** Read site setting (cached per request) */
function setting(string $key, string $default = ''): string {
    static $cache = null;
    if ($cache === null) {
        global $pdo;
        $cache = [];
        try {
            $rows = $pdo->query('SELECT key_name, value FROM settings')->fetchAll();
            foreach ($rows as $r) $cache[$r['key_name']] = $r['value'];
        } catch (Throwable) {}
    }
    return $cache[$key] ?? $default;
}

/** Discount % for a product */
function off_percent(array $p): ?int {
    if (empty($p['mrp']) || $p['mrp'] <= $p['price']) return null;
    return (int) round((1 - $p['price'] / $p['mrp']) * 100);
}

/** Current page filename (for nav) */
function current_page(): string {
    return basename($_SERVER['PHP_SELF'] ?? 'index.php');
}

/** Is a nav link active? */
function nav_active(string $file): string {
    return current_page() === $file ? ' active' : '';
}

/** Render a flash block */
function render_flash(): void {
    foreach (flash_get() as $f) {
        echo '<div class="flash flash-' . e($f['type']) . '">' . e($f['msg']) . '</div>';
    }
}