<?php
// includes/handlers/cart-handler.php
// Included at top of any page that needs cart AJAX.
// Caller must check: if ($_SERVER['REQUEST_METHOD']==='POST' && isset($_POST['action'])) require this.

if ($_SERVER['REQUEST_METHOD'] !== 'POST') return;
if (!isset($_POST['action'])) return;

$action = $_POST['action'];
if (!in_array($action, ['cart_add','cart_update','cart_remove','cart_data'], true)) return;

if (!csrf_verify($_POST['_token'] ?? null)) {
    json_out(['ok' => false, 'error' => 'Session expired. Please refresh.'], 419);
}

$cartId = cart_current_id();

switch ($action) {

    case 'cart_add':
        $productId = (int) ($_POST['product_id'] ?? 0);
        $qty       = max(1, (int) ($_POST['qty'] ?? 1));

        if ($productId <= 0) json_out(['ok' => false, 'error' => 'Invalid product'], 400);

        $stmt = $pdo->prepare('SELECT id, name, price, stock, is_active FROM products WHERE id=? LIMIT 1');
        $stmt->execute([$productId]);
        $product = $stmt->fetch();

        if (!$product || !$product['is_active']) json_out(['ok' => false, 'error' => 'Product unavailable'], 404);
        if ($product['stock'] < $qty)              json_out(['ok' => false, 'error' => 'Not enough stock'], 409);

        $pdo->prepare(
            "INSERT INTO cart_items (cart_id, product_id, qty, price_at_add)
             VALUES (?, ?, ?, ?)
             ON DUPLICATE KEY UPDATE qty = qty + VALUES(qty)"
        )->execute([$cartId, $productId, $qty, $product['price']]);

        json_out([
            'ok'       => true,
            'message'  => $product['name'] . ' added to cart',
            'qty'      => cart_qty($cartId),
            'subtotal' => inr(cart_subtotal($cartId)),
            'items'    => cart_items($cartId),
        ]);

    case 'cart_update':
        $itemId = (int) ($_POST['item_id'] ?? 0);
        $qty    = max(1, (int) ($_POST['qty'] ?? 1));
        $pdo->prepare('UPDATE cart_items SET qty=? WHERE id=? AND cart_id=?')
            ->execute([$qty, $itemId, $cartId]);
        json_out([
            'ok'       => true,
            'qty'      => cart_qty($cartId),
            'subtotal' => inr(cart_subtotal($cartId)),
        ]);

    case 'cart_remove':
        $itemId = (int) ($_POST['item_id'] ?? 0);
        $pdo->prepare('DELETE FROM cart_items WHERE id=? AND cart_id=?')->execute([$itemId, $cartId]);
        json_out([
            'ok'       => true,
            'message'  => 'Item removed',
            'qty'      => cart_qty($cartId),
            'subtotal' => inr(cart_subtotal($cartId)),
        ]);

    case 'cart_data':
        json_out([
            'ok'       => true,
            'items'    => cart_items($cartId),
            'qty'      => cart_qty($cartId),
            'subtotal' => inr(cart_subtotal($cartId)),
        ]);
}