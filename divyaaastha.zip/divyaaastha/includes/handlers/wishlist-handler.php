<?php
// includes/handlers/wishlist-handler.php
if ($_SERVER['REQUEST_METHOD'] !== 'POST') return;
if (($_POST['action'] ?? '') !== 'wishlist_toggle') return;

if (!csrf_verify($_POST['_token'] ?? null)) {
    json_out(['ok' => false, 'error' => 'Session expired'], 419);
}

if (!is_logged_in()) {
    json_out(['ok' => false, 'login' => true, 'error' => 'Please login to use wishlist'], 401);
}

$userId    = $_SESSION['user_id'];
$productId = (int) ($_POST['product_id'] ?? 0);

if ($productId <= 0) json_out(['ok' => false, 'error' => 'Invalid product'], 400);

$stmt = $pdo->prepare('SELECT id FROM wishlists WHERE user_id=? AND product_id=? LIMIT 1');
$stmt->execute([$userId, $productId]);
$existing = $stmt->fetchColumn();

if ($existing) {
    $pdo->prepare('DELETE FROM wishlists WHERE id=?')->execute([$existing]);
    $active = false;
    $msg    = 'Removed from wishlist';
} else {
    $pdo->prepare('INSERT INTO wishlists (user_id, product_id) VALUES (?, ?)')->execute([$userId, $productId]);
    $active = true;
    $msg    = 'Added to wishlist';
}

json_out([
    'ok'      => true,
    'active'  => $active,
    'count'   => wishlist_count(),
    'message' => $msg,
]);