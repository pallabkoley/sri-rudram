<?php
require_once __DIR__ . '/config/config.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action'])) {
    require BASE_PATH . '/includes/handlers/cart-handler.php';
}

$pujas = get_all_pujas();
$temples = get_all_temples();

$pageTitle = 'Puja Services — Book Online Puja at Sacred Temples';
$pageDesc  = 'Book authentic Hindu pujas performed by verified priests at India\'s most sacred temples.';
require BASE_PATH . '/includes/header.php';
?>

<section class="page-hero">
  <div class="page-hero-mandala"></div>
  <div class="container">
    <nav class="breadcrumb">
      <a href="<?= url('index.php') ?>">Home</a>
      <span class="sep">›</span>
      <span class="current">Puja</span>
    </nav>
    <span class="eyebrow">Book A Ritual</span>
    <h1>Puja Services</h1>
    <p>Book authentic rituals performed by experienced priests at sacred temples across Bharat. Receive prasad at your home.</p>
  </div>
</section>

<section class="section">
  <div class="container">
    <div class="filter-bar">
      <button class="filter-chip active">All Pujas</button>
      <?php
      $types = [];
      foreach ($pujas as $p) {
        if (!empty($p['temple_name'])) $types[$p['temple_name']] = true;
      }
      foreach (array_slice(array_keys($types), 0, 5) as $t): ?>
        <button class="filter-chip"><?= e($t) ?></button>
      <?php endforeach; ?>
      <span class="filter-count"><?= count($pujas) ?> pujas available</span>
    </div>

    <div class="puja-grid">
      <?php foreach ($pujas as $p): ?>
        <article class="puja-card reveal">
          <div class="pj-media">
            <?= img_tag($p['image_url'], $p['name']) ?>
            <?php if (!empty($p['badge'])): ?>
              <span class="pj-badge <?= e($p['badge_style'] ?: 'plum') ?>"><?= e($p['badge']) ?></span>
            <?php endif; ?>
            <?php if (!empty($p['city'])): ?>
              <span class="pj-loc">📍 <?= e($p['city']) ?></span>
            <?php endif; ?>
          </div>
          <div class="pj-body">
            <h3><?= e($p['name']) ?></h3>
            <p><?= e($p['short_desc']) ?></p>
            <div class="pj-foot">
              <div class="pj-price">
                <span>Starting at</span>
                <b><?= inr($p['price']) ?></b>
              </div>
              <a href="<?= url('puja.php?slug=' . $p['slug']) ?>" class="btn btn-terra btn-sm">Book Puja</a>
            </div>
          </div>
        </article>
      <?php endforeach; ?>
    </div>
  </div>
</section>

<?php require BASE_PATH . '/includes/footer.php'; ?>