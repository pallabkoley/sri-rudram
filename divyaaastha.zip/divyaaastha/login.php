<?php
require_once __DIR__ . '/config/config.php';

if (is_logged_in()) redirect('account.php');

$error = '';
$email = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!csrf_verify($_POST['_token'] ?? null)) {
        $error = 'Session expired. Please try again.';
    } else {
        $email = trim($_POST['email'] ?? '');
        $pass  = $_POST['password'] ?? '';

        if (!$email || !$pass) {
            $error = 'Please enter both email and password.';
        } else {
            $stmt = $pdo->prepare('SELECT id, name, password_hash, role FROM users WHERE email = ? AND status = 1 LIMIT 1');
            $stmt->execute([$email]);
            $user = $stmt->fetch();

            if ($user && password_verify($pass, $user['password_hash'])) {
                login_user($user);
                $redirect = $_SESSION['redirect_after_login'] ?? 'account.php';
                unset($_SESSION['redirect_after_login']);
                flash_set('success', 'Welcome back, ' . $user['name'] . '!');
                redirect($redirect);
            } else {
                $error = 'Invalid email or password.';
            }
        }
    }
}

$pageTitle = 'Login — Divya Aastha';
require BASE_PATH . '/includes/header.php';
?>

<section class="section">
  <div class="auth-wrap">
    <div class="auth-card">
      <div class="auth-head">
        <span class="brand-mark">ॐ</span>
        <h1>Welcome Back</h1>
        <p>Login to your Divya Aastha account</p>
      </div>

      <?php if ($error): ?><div class="flash flash-error"><?= e($error) ?></div><?php endif; ?>
      <?php foreach (flash_get() as $f): ?>
        <div class="flash flash-<?= e($f['type']) ?>"><?= e($f['msg']) ?></div>
      <?php endforeach; ?>

      <form method="POST">
        <?= csrf_field() ?>
        <div class="form-group">
          <label>Email Address</label>
          <input type="email" name="email" required value="<?= e($email) ?>" autofocus>
        </div>
        <div class="form-group">
          <label>Password</label>
          <input type="password" name="password" required>
        </div>
        <button type="submit" class="btn btn-terra btn-block">Login</button>
      </form>

      <div class="auth-foot">
        New to Divya Aastha? <a href="<?= url('register.php') ?>">Create an account</a>
      </div>
    </div>
  </div>
</section>

<?php require BASE_PATH . '/includes/footer.php'; ?>