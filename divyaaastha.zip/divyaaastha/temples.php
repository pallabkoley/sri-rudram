<?php
require_once __DIR__ . '/config/config.php';
$temples = get_all_temples();
$pageTitle = 'Sacred Temples of Bharat';
$pageDesc  = 'Explore sacred temples from Shakti Peethas, Jyotirlingas and other revered pilgrimage destinations.';
require BASE_PATH . '/includes/header.php';
?>

<section class="page-hero">
  <div class="page-hero-mandala"></div>
  <div class="container">
    <nav class="breadcrumb">
      <a href="<?= url('index.php') ?>">Home</a>
      <span class="sep">›</span>
      <span class="current">Temples</span>
    </nav>
    <span class="eyebrow">Divine Destinations</span>
    <h1>Sacred Temples of Bharat</h1>
    <p>Offer pujas at these revered shrines and receive divine blessings.</p>
  </div>
</section>

<section class="section">
  <div class="container">
    <div class="puja-grid">
      <?php foreach ($temples as $t): ?>
        <article class="temple-card reveal">
          <div class="temple-media">
            <?= img_tag($t['image_url'], $t['name']) ?>
            <span class="temple-type"><?= e($t['type']) ?></span>
            <span class="temple-loc">📍 <?= e($t['city']) ?>, <?= e($t['state']) ?></span>
          </div>
          <div class="temple-body">
            <h3><?= e($t['name']) ?></h3>
            <p><?= e($t['short_desc']) ?></p>
            <a href="<?= url('temple.php?slug=' . $t['slug']) ?>" class="btn btn-terra btn-sm">View Temple</a>
          </div>
        </article>
      <?php endforeach; ?>
    </div>
  </div>
</section>

<?php require BASE_PATH . '/includes/footer.php'; ?>