<?php
require_once __DIR__ . '/config/config.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action'])) {
    require BASE_PATH . '/includes/handlers/cart-handler.php';
}

require_login();

$cartId = cart_current_id();
$items = cart_items($cartId);
$subtotal = cart_subtotal($cartId);

if (empty($items)) {
    flash_set('info', 'Your cart is empty.');
    redirect('shop.php');
}

$user = current_user();
$pageTitle = 'Checkout — ' . APP_NAME;
require BASE_PATH . '/includes/header.php';
?>

<section class="page-hero">
  <div class="page-hero-mandala"></div>
  <div class="container">
    <nav class="breadcrumb">
      <a href="<?= url('index.php') ?>">Home</a>
      <span class="sep">›</span>
      <a href="<?= url('cart.php') ?>">Cart</a>
      <span class="sep">›</span>
      <span class="current">Checkout</span>
    </nav>
    <h1>Checkout</h1>
  </div>
</section>

<section class="section">
  <div class="container">
    <form method="POST" action="<?= url('place-order.php') ?>">
      <?= csrf_field() ?>
      <div class="cart-page-grid">
        <div class="cart-list" style="padding:28px">
          <h3 style="font-size:18px;margin-bottom:22px">Shipping Details</h3>

          <div class="form-group">
            <label>Full Name</label>
            <input type="text" name="ship_name" required value="<?= e($user['name']) ?>">
          </div>
          <div class="form-group">
            <label>Phone</label>
            <input type="tel" name="ship_phone" required value="<?= e($user['phone'] ?? '') ?>">
          </div>
          <div class="form-group">
            <label>Address Line 1</label>
            <input type="text" name="ship_line1" required>
          </div>
          <div class="form-group">
            <label>Address Line 2 (optional)</label>
            <input type="text" name="ship_line2">
          </div>
          <div style="display:grid;grid-template-columns:1fr 1fr;gap:14px">
            <div class="form-group">
              <label>City</label>
              <input type="text" name="ship_city" required>
            </div>
            <div class="form-group">
              <label>State</label>
              <input type="text" name="ship_state" required>
            </div>
          </div>
          <div class="form-group">
            <label>Pincode</label>
            <input type="text" name="ship_pincode" required pattern="[0-9]{6}">
          </div>
        </div>

        <aside class="cart-summary">
          <h3>Order Summary</h3>
          <?php foreach ($items as $item): ?>
            <div class="cs-row">
              <span><?= e($item['name']) ?> × <?= (int) $item['qty'] ?></span>
              <span><?= inr($item['price'] * $item['qty']) ?></span>
            </div>
          <?php endforeach; ?>
          <div class="cs-row" style="padding-top:12px;border-top:1px solid var(--line)"><span>Subtotal</span><span><?= inr($subtotal) ?></span></div>
          <div class="cs-row"><span>Shipping</span><span style="color:var(--muted-sage);font-weight:600">Complimentary</span></div>
          <div class="cs-row total"><span>Total</span><span><?= inr($subtotal) ?></span></div>
          <button type="submit" class="btn btn-terra" style="width:100%;margin-top:14px;padding:15px 22px">Place Order</button>
        </aside>
      </div>
    </form>
  </div>
</section>

<?php require BASE_PATH . '/includes/footer.php'; ?>