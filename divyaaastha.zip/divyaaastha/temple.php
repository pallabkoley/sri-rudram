<?php
require_once __DIR__ . '/config/config.php';
$slug = $_GET['slug'] ?? '';
$temple = get_temple_by_slug($slug);

if (!$temple) { http_response_code(404); require BASE_PATH . '/404.php'; exit; }

// Get pujas at this temple
$stmt = $pdo->prepare('SELECT * FROM pujas WHERE temple_id = ? AND is_active = 1 ORDER BY sort_order ASC');
$stmt->execute([$temple['id']]);
$pujas = $stmt->fetchAll();

$pageTitle = $temple['name'] . ' — ' . $temple['city'];
$pageDesc  = $temple['short_desc'];
require BASE_PATH . '/includes/header.php';
?>

<section class="page-hero">
  <div class="page-hero-mandala"></div>
  <div class="container">
    <nav class="breadcrumb">
      <a href="<?= url('index.php') ?>">Home</a>
      <span class="sep">›</span>
      <a href="<?= url('temples.php') ?>">Temples</a>
      <span class="sep">›</span>
      <span class="current"><?= e($temple['name']) ?></span>
    </nav>
    <span class="eyebrow"><?= e($temple['type']) ?></span>
    <h1><?= e($temple['name']) ?></h1>
    <p><?= e($temple['short_desc']) ?></p>
  </div>
</section>

<section class="container">
  <div class="detail-grid">
    <div class="detail-media">
      <?= img_tag($temple['image_url'], $temple['name'], '', false) ?>
    </div>
    <div class="detail-info">
      <h1><?= e($temple['name']) ?></h1>
      <div class="detail-meta">
        <span class="m-item">📍 <b><?= e($temple['city']) ?>, <?= e($temple['state']) ?></b></span>
        <span class="m-item">🛕 <b><?= e($temple['type']) ?></b></span>
      </div>
      <div class="detail-desc">
        <p><?= e($temple['short_desc']) ?></p>
        <?php if (!empty($temple['description'])): ?>
          <h3>About the Temple</h3>
          <p><?= nl2br(e($temple['description'])) ?></p>
        <?php endif; ?>
      </div>
    </div>
  </div>
</section>

<?php if (!empty($pujas)): ?>
<section class="section sand">
  <div class="container">
    <div class="section-head">
      <span class="eyebrow center">Available Pujas</span>
      <h2>Pujas at <?= e($temple['name']) ?></h2>
      <p>Book these sacred rituals performed at this temple.</p>
    </div>
    <div class="puja-grid">
      <?php foreach ($pujas as $p): ?>
        <article class="puja-card reveal">
          <div class="pj-media">
            <?= img_tag($p['image_url'], $p['name']) ?>
            <?php if (!empty($p['badge'])): ?>
              <span class="pj-badge <?= e($p['badge_style'] ?: 'plum') ?>"><?= e($p['badge']) ?></span>
            <?php endif; ?>
          </div>
          <div class="pj-body">
            <h3><?= e($p['name']) ?></h3>
            <p><?= e($p['short_desc']) ?></p>
            <div class="pj-foot">
              <div class="pj-price"><span>From</span><b><?= inr($p['price']) ?></b></div>
              <a href="<?= url('puja.php?slug=' . $p['slug']) ?>" class="btn btn-terra btn-sm">Book</a>
            </div>
          </div>
        </article>
      <?php endforeach; ?>
    </div>
  </div>
</section>
<?php endif; ?>

<?php require BASE_PATH . '/includes/footer.php'; ?>