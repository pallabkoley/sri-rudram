<?php
require_once __DIR__ . '/config/config.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action'])) {
    require BASE_PATH . '/includes/handlers/cart-handler.php';
    require BASE_PATH . '/includes/handlers/wishlist-handler.php';
}

$catSlug = $_GET['cat'] ?? null;
$products = get_all_products($catSlug);
$categories = get_product_categories();

$pageTitle = 'Siddha Store — Sacred Gemstones & Consecrated Tools';
$pageDesc  = 'Shop authentic rudraksha, healing crystals, malas and sacred tools.';
require BASE_PATH . '/includes/header.php';
?>

<section class="page-hero">
  <div class="page-hero-mandala"></div>
  <div class="container">
    <nav class="breadcrumb">
      <a href="<?= url('index.php') ?>">Home</a>
      <span class="sep">›</span>
      <span class="current">Shop</span>
    </nav>
    <span class="eyebrow">Siddha Store</span>
    <h1>Sacred Gemstones &amp; Consecrated Tools</h1>
    <p>Authentic rudraksha, healing crystals, malas and sacred tools handpicked for your spiritual well-being.</p>
  </div>
</section>

<section class="section">
  <div class="container">
    <div class="filter-bar">
      <a href="<?= url('shop.php') ?>" class="filter-chip <?= !$catSlug ? 'active' : '' ?>">All Products</a>
      <?php foreach ($categories as $c): ?>
        <a href="<?= url('shop.php?cat=' . $c['slug']) ?>"
           class="filter-chip <?= $catSlug === $c['slug'] ? 'active' : '' ?>">
          <?= e($c['name']) ?>
        </a>
      <?php endforeach; ?>
      <span class="filter-count"><?= count($products) ?> products</span>
    </div>

    <div class="puja-grid">
      <?php foreach ($products as $p): ?>
        <?php $off = off_percent($p); ?>
        <article class="shop-card reveal">
          <div class="shop-media">
            <?= img_tag($p['image_url'], $p['name']) ?>
            <?php if (!empty($p['badge'])): ?>
              <span class="shop-badge <?= e($p['badge_style'] ?: 'plum') ?>"><?= e($p['badge']) ?></span>
            <?php endif; ?>
            <button class="wish-btn" data-wish-id="<?= (int) $p['id'] ?>" aria-label="Wishlist">
              <svg viewBox="0 0 24 24"><path d="M20.8 4.6a5.5 5.5 0 0 0-7.8 0L12 5.7l-1-1.1a5.5 5.5 0 0 0-7.8 7.8l1.1 1L12 21l7.7-7.6 1.1-1a5.5 5.5 0 0 0 0-7.8z"/></svg>
            </button>
          </div>
          <div class="shop-body">
            <h3><a href="<?= url('product.php?slug=' . $p['slug']) ?>"><?= e($p['name']) ?></a></h3>
            <p><?= e($p['short_desc']) ?></p>
            <div class="shop-price">
              <span class="now"><?= inr($p['price']) ?></span>
              <?php if (!empty($p['mrp'])): ?><span class="was"><?= inr($p['mrp']) ?></span><?php endif; ?>
              <?php if ($off): ?><span class="off"><?= $off ?>% OFF</span><?php endif; ?>
            </div>
            <div class="shop-actions">
              <button class="btn btn-plum" data-add-id="<?= (int) $p['id'] ?>"
                      data-add-name="<?= e($p['name']) ?>"
                      data-add-price="<?= (int) $p['price'] ?>"
                      data-add-img="<?= e(upload_url($p['image_url'])) ?>">Buy Now</button>
            </div>
          </div>
        </article>
      <?php endforeach; ?>
    </div>
  </div>
</section>

<?php require BASE_PATH . '/includes/footer.php'; ?>