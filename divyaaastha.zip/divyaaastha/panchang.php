<?php
require_once __DIR__ . '/config/config.php';
$pageTitle = 'Panchang — Today\'s Hindu Calendar';
require BASE_PATH . '/includes/header.php';
?>

<section class="page-hero">
  <div class="page-hero-mandala"></div>
  <div class="container">
    <nav class="breadcrumb">
      <a href="<?= url('index.php') ?>">Home</a>
      <span class="sep">›</span>
      <span class="current">Panchang</span>
    </nav>
    <span class="eyebrow">Daily Hindu Calendar</span>
    <h1>Today's Panchang</h1>
    <p>Stay connected with cosmic energies and plan your day better.</p>
  </div>
</section>

<section class="section">
  <div class="container">
    <div class="coming-soon">
      <div class="om">🕉</div>
      <h2>Panchang Coming Soon</h2>
      <p>We are integrating a live Panchang with Tithi, Nakshatra, Yoga, Karana, and auspicious muhurat timings.</p>
      <a href="<?= url('index.php') ?>" class="btn btn-outline">Back to Home</a>
    </div>
  </div>
</section>

<?php require BASE_PATH . '/includes/footer.php'; ?>