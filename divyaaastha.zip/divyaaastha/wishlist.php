<?php
require_once __DIR__ . '/config/config.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action'])) {
    require BASE_PATH . '/includes/handlers/wishlist-handler.php';
    require BASE_PATH . '/includes/handlers/cart-handler.php';
}

if (!is_logged_in()) {
    flash_set('info', 'Please login to view your wishlist.');
    redirect('login.php');
}

$items = wishlist_items();
$pageTitle = 'My Wishlist — Divya Aastha';
require BASE_PATH . '/includes/header.php';
?>

<section class="page-hero">
  <div class="page-hero-mandala"></div>
  <div class="container">
    <nav class="breadcrumb">
      <a href="<?= url('index.php') ?>">Home</a>
      <span class="sep">›</span>
      <span class="current">Wishlist</span>
    </nav>
    <h1>My Wishlist</h1>
    <p>Your saved sacred items.</p>
  </div>
</section>

<section class="section">
  <div class="container">
    <?php if (empty($items)): ?>
      <div class="cart-empty">
        <div class="om">♡</div>
        <h3>Your wishlist is empty</h3>
        <p>Save your favourite sacred items to view them later.</p>
        <a href="<?= url('shop.php') ?>" class="btn btn-terra">Explore Store</a>
      </div>
    <?php else: ?>
      <div class="puja-grid">
        <?php foreach ($items as $p): ?>
          <article class="shop-card">
            <div class="shop-media">
              <?= img_tag($p['image_url'], $p['name']) ?>
              <button class="wish-btn active" data-wish-id="<?= (int) $p['id'] ?>">✕</button>
            </div>
            <div class="shop-body">
              <h3><a href="<?= url('product.php?slug=' . $p['slug']) ?>"><?= e($p['name']) ?></a></h3>
              <div class="shop-price"><span class="now"><?= inr($p['price']) ?></span></div>
              <div class="shop-actions">
                <button class="btn btn-plum" data-add-id="<?= (int) $p['id'] ?>"
                        data-add-name="<?= e($p['name']) ?>"
                        data-add-price="<?= (int) $p['price'] ?>"
                        data-add-img="<?= e(upload_url($p['image_url'])) ?>">Add to Cart</button>
              </div>
            </div>
          </article>
        <?php endforeach; ?>
      </div>
    <?php endif; ?>
  </div>
</section>

<?php require BASE_PATH . '/includes/footer.php'; ?>