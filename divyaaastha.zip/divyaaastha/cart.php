<?php
require_once __DIR__ . '/config/config.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action'])) {
    require BASE_PATH . '/includes/handlers/cart-handler.php';
}

$cartId = cart_current_id();
$items = cart_items($cartId);
$subtotal = cart_subtotal($cartId);

$pageTitle = 'Your Cart — Divya Aastha';
require BASE_PATH . '/includes/header.php';
?>

<section class="page-hero">
  <div class="page-hero-mandala"></div>
  <div class="container">
    <nav class="breadcrumb">
      <a href="<?= url('index.php') ?>">Home</a>
      <span class="sep">›</span>
      <span class="current">Cart</span>
    </nav>
    <h1>Your Cart</h1>
  </div>
</section>

<section class="section">
  <div class="container">
    <?php if (empty($items)): ?>
      <div class="cart-empty">
        <div class="om">ॐ</div>
        <h3>Your cart is empty</h3>
        <p>Add sacred essentials to begin your journey.</p>
        <a href="<?= url('shop.php') ?>" class="btn btn-terra">Explore Siddha Store</a>
      </div>
    <?php else: ?>
      <div class="cart-page-grid">
        <div class="cart-list">
          <?php foreach ($items as $item): ?>
            <div class="cart-row" data-id="<?= (int) $item['id'] ?>">
              <?= img_tag($item['image_url'], $item['name']) ?>
              <div class="cart-row-info">
                <h4><a href="<?= url('product.php?slug=' . $item['slug']) ?>"><?= e($item['name']) ?></a></h4>
                <div class="price"><?= inr($item['price']) ?></div>
              </div>
              <div class="qty">
                <button data-act="dec">−</button>
                <span><?= (int) $item['qty'] ?></span>
                <button data-act="inc">+</button>
              </div>
              <button class="cart-row-remove" data-act="remove">✕</button>
            </div>
          <?php endforeach; ?>
        </div>

        <aside class="cart-summary">
          <h3>Order Summary</h3>
          <div class="cs-row"><span>Subtotal</span><span id="cartSubtotal"><?= inr($subtotal) ?></span></div>
          <div class="cs-row"><span>Shipping</span><span style="color:var(--muted-sage);font-weight:600">Complimentary</span></div>
          <div class="cs-row total"><span>Total</span><span id="cartTotal"><?= inr($subtotal) ?></span></div>
          <a href="<?= url('checkout.php') ?>" class="btn btn-terra">Proceed to Checkout</a>
          <a href="<?= url('shop.php') ?>" class="btn btn-outline" style="margin-top:10px">Continue Shopping</a>
        </aside>
      </div>
    <?php endif; ?>
  </div>
</section>

<?php require BASE_PATH . '/includes/footer.php'; ?>