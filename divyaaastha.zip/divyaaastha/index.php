<?php
require_once __DIR__ . '/config/config.php';

// ═══════════════════════════════════════════
// AJAX handlers (before any output)
// ═══════════════════════════════════════════
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action'])) {
    require BASE_PATH . '/includes/handlers/cart-handler.php';
    require BASE_PATH . '/includes/handlers/wishlist-handler.php';
    require BASE_PATH . '/includes/handlers/newsletter-handler.php';
    // If action wasn't handled, fall through to normal page
}

// ═══════════════════════════════════════════
// Page data
// ═══════════════════════════════════════════
$templesLight = get_temples_light();
$templesDark  = get_temples_dark();
$pujas        = get_popular_pujas(8);
$products     = get_featured_products(12);
$articles     = get_featured_articles(8);
$trending     = get_trending_articles(4);
$festivals    = get_upcoming_festivals(6);
$testimonials = get_testimonials();
$faqs         = get_faqs();
$gyanCats     = get_gyan_categories();

$pageTitle = 'Divya Aastha — Puja Booking, Siddha Store & Dharmik Gyan';
$pageDesc  = 'Book authentic Hindu pujas, receive sacred prasad at home, shop rudraksha & consecrated tools.';

require BASE_PATH . '/includes/header.php';
?>

<!-- ═══════════════ HERO ═══════════════ -->
<section class="hero" id="home">
  <div class="hero-mandala"></div>
  <div class="container hero-grid">
    <div class="hero-content">
      <span class="hero-pill">
        <span class="avatars"><i>R</i><i>S</i><i>A</i></span>
        <?= e(setting('devotee_count', '10 Lakh+')) ?> Happy Devotees
      </span>
      <h1>
        EXPERIENCE HINDU<br>
        <span class="accent">Pujas &amp; Rituals</span><br>
        WITH SHRADDHA
        <span class="sub">Authentic temples. Verified priests. Divine blessings.</span>
      </h1>
      <div class="hero-rule"><span>ॐ</span></div>
      <p class="hero-lead">Offer Puja, watch Darshan videos, receive Holy Prasad at your home from the most auspicious temples across India.</p>

      <div class="hero-trust">
        <span class="trust-chip"><span class="stars">★★★★★</span> <?= e(setting('rating', '4.8')) ?> / 5 Rating</span>
        <span class="trust-chip">Authentic Prasad</span>
        <span class="trust-chip">Verified Priests</span>
      </div>

      <div class="hero-cta">
        <a href="<?= url('pujas.php') ?>" class="btn btn-terra">Participate in Puja →</a>
        <a href="<?= url('shop.php') ?>" class="btn btn-outline">Explore Sacred Store</a>
      </div>
    </div>

    <div class="hero-visual">
      <div class="hero-collage">
        <figure class="hc-item hc-main">
          <?= img_tag('https://images.unsplash.com/photo-1599661046289-e31897846e41?auto=format&fit=crop&w=900&q=80', 'Kashi Vishwanath', '', false) ?>
          <figcaption class="hc-cap">Kashi Vishwanath · Varanasi</figcaption>
        </figure>
        <figure class="hc-item hc-circle">
          <?= img_tag('https://images.unsplash.com/photo-1604608672516-f1b9b1d1c0b9?auto=format&fit=crop&w=500&q=80', 'Diyas glowing', '', false) ?>
        </figure>
        <figure class="hc-item hc-a">
          <?= img_tag('https://images.unsplash.com/photo-1609766857041-ed402ea8069a?auto=format&fit=crop&w=600&q=80', 'Puja thali', '', false) ?>
        </figure>
        <figure class="hc-item hc-b">
          <?= img_tag('https://images.unsplash.com/photo-1595246140625-573b715d11dc?auto=format&fit=crop&w=600&q=80', 'Marigold flowers', '', false) ?>
        </figure>
        <div class="hc-chip">
          <span class="fc-ico">🕉</span>
          <span><b>Live Darshan</b><span>12 temples online</span></span>
        </div>
        <div class="hc-chip-2">
          <span class="dot"></span>
          Prasad shipped across Bharat
        </div>
      </div>
    </div>
  </div>
</section>

<!-- ═══════════════ FEATURED ON ═══════════════ -->
<section class="featured-on">
  <div class="container">
    <p class="fo-title">Featured On</p>
    <div class="fo-row">
      <?php foreach (['Economic Times','Times of India','Hindustan Times','India Today','YourStory','NDTV'] as $outlet): ?>
        <span class="fo-item"><?= e($outlet) ?></span>
      <?php endforeach; ?>
    </div>
  </div>
</section>

<!-- ═══════════════ TEMPLES CAROUSEL ═══════════════ -->
<section class="section sand" id="temples">
  <div class="container">
    <div class="carousel-head">
      <div class="section-head left">
        <span class="eyebrow">Divine Destinations</span>
        <h2>Sacred Temples of Bharat</h2>
        <p>Offer pujas at these revered shrines and receive divine blessings.</p>
      </div>
      <div class="carousel-nav">
        <button class="c-nav" id="templePrev">‹</button>
        <button class="c-nav" id="templeNext">›</button>
      </div>
    </div>

    <div class="carousel-track" id="templeTrack">
      <?php foreach ($templesLight as $t): ?>
        <article class="temple-card">
          <div class="temple-media">
            <?= img_tag($t['image_url'], $t['name']) ?>
            <span class="temple-type"><?= e($t['type']) ?></span>
            <span class="temple-loc">📍 <?= e($t['city']) ?>, <?= e($t['state']) ?></span>
          </div>
          <div class="temple-body">
            <h3><?= e($t['name']) ?></h3>
            <p><?= e($t['short_desc']) ?></p>
            <a href="<?= url('temple.php?slug=' . $t['slug']) ?>" class="btn btn-terra btn-sm">Book Puja</a>
          </div>
        </article>
      <?php endforeach; ?>
    </div>
    <div class="progress-bar"><div class="pb-fill" id="templeProgress"></div></div>
  </div>
</section>

<!-- ═══════════════ STORE ═══════════════ -->
<section class="section" id="store">
  <div class="container">
    <div class="carousel-head">
      <div class="section-head left">
        <span class="eyebrow">Siddha Store</span>
        <h2>Siddha Store — Sacred Gemstones &amp; Consecrated Tools</h2>
        <p>Authentic rudraksha, healing crystals, malas and sacred tools handpicked for your spiritual well-being.</p>
      </div>
      <div class="carousel-nav">
        <button class="c-nav" id="shopPrev">‹</button>
        <button class="c-nav" id="shopNext">›</button>
      </div>
    </div>

    <div class="carousel-track" id="shopTrack">
      <?php foreach ($products as $p): ?>
        <?php $off = off_percent($p); ?>
        <article class="shop-card">
          <div class="shop-media">
            <?= img_tag($p['image_url'], $p['name']) ?>
            <?php if ($p['badge']): ?>
              <span class="shop-badge <?= e($p['badge_style']) ?>"><?= e($p['badge']) ?></span>
            <?php endif; ?>
            <button class="wish-btn" data-wish-id="<?= (int) $p['id'] ?>" aria-label="Wishlist">
              <svg viewBox="0 0 24 24"><path d="M20.8 4.6a5.5 5.5 0 0 0-7.8 0L12 5.7l-1-1.1a5.5 5.5 0 0 0-7.8 7.8l1.1 1L12 21l7.7-7.6 1.1-1a5.5 5.5 0 0 0 0-7.8z"/></svg>
            </button>
          </div>
          <div class="shop-body">
            <h3><?= e($p['name']) ?></h3>
            <p><?= e($p['short_desc']) ?></p>
            <div class="shop-price">
              <span class="now"><?= inr($p['price']) ?></span>
              <?php if (!empty($p['mrp'])): ?><span class="was"><?= inr($p['mrp']) ?></span><?php endif; ?>
              <?php if ($off): ?><span class="off"><?= $off ?>% OFF</span><?php endif; ?>
            </div>
            <button class="btn btn-plum" data-add-to-cart data-product-id="<?= (int) $p['id'] ?>">Buy Now</button>
          </div>
        </article>
      <?php endforeach; ?>
    </div>
    <div class="progress-bar"><div class="pb-fill" id="shopProgress"></div></div>
  </div>
</section>

<!-- ═══════════════ HOW TO BOOK ═══════════════ -->
<section class="section sand">
  <div class="container">
    <div class="section-head">
      <span class="eyebrow center">Simple &amp; Sacred</span>
      <h2>How to Book Puja on <?= e(APP_NAME) ?></h2>
      <p>Simple process — register, receive puja proof, get prasad at home.</p>
    </div>
    <div class="steps">
      <?php
      $steps = [
        ['Choose Your Puja',        'Select the puja according to your spiritual needs.'],
        ['Choose Temple & Date',    'Select your preferred temple and available puja date.'],
        ['Complete Booking',        'Enter your details and complete secure payment.'],
        ['Receive Blessings & Prasad', 'The puja is performed and sacred prasad is delivered.'],
      ];
      foreach ($steps as $i => [$t, $d]): ?>
        <article class="step">
          <div class="step-num"><?= str_pad((string) ($i+1), 2, '0', STR_PAD_LEFT) ?></div>
          <h3><?= e($t) ?></h3>
          <p><?= e($d) ?></p>
        </article>
      <?php endforeach; ?>
    </div>
  </div>
</section>

<!-- ═══════════════ YATRA / GYAN TILES ═══════════════ -->
<section class="section" id="gyan">
  <div class="container">
    <div class="section-head">
      <span class="eyebrow center">Begin Your Journey</span>
      <h2>Your Dharmik Yatra with <?= e(APP_NAME) ?></h2>
      <p>A seamless journey through puja, prasadam, knowledge and spiritual experiences.</p>
    </div>
    <div class="yatra-grid">
      <?php foreach (array_slice($gyanCats, 0, 5) as $cat): ?>
        <article class="yatra-card">
          <div class="yatra-ico">
            <svg viewBox="0 0 24 24"><path d="M12 3v18"/><path d="M6 8c3 0 6-2 6-5 0 3 3 5 6 5"/></svg>
          </div>
          <h3><?= e($cat['name']) ?></h3>
          <p><?= e($cat['description']) ?></p>
          <a href="<?= url('gyan.php?cat=' . $cat['slug']) ?>" class="btn-ghost">Explore →</a>
        </article>
      <?php endforeach; ?>
    </div>
  </div>
</section>

<!-- ═══════════════ TESTIMONIALS ═══════════════ -->
<section class="section sand">
  <div class="container">
    <div class="section-head">
      <span class="eyebrow center">Devotee Voices</span>
      <h2>What Devotees Say</h2>
      <p>Devotees rate <?= e(APP_NAME) ?> highly for authentic puja &amp; prasad delivery.</p>
    </div>
    <div class="testi-grid">
      <?php foreach ($testimonials as $t): ?>
        <article class="testi-card">
          <div class="testi-stars"><?= str_repeat('★', (int) $t['rating']) ?></div>
          <p><?= e($t['message']) ?></p>
          <div class="testi-user">
            <span class="testi-avatar"><?= e($t['initials']) ?></span>
            <span><b><?= e($t['name']) ?></b><span><?= e($t['city']) ?></span></span>
          </div>
        </article>
      <?php endforeach; ?>
    </div>
  </div>
</section>

<!-- ═══════════════ GYAN TILES ═══════════════ -->
<section class="section">
  <div class="container">
    <div class="section-head">
      <span class="eyebrow center">Dharmik Gyan</span>
      <h2>Collection of Dharmik Gyan</h2>
      <p>Mantra, Stotra, Chalisa, Aarti &amp; sacred wisdom for every devotee.</p>
    </div>
    <div class="gyan-grid">
      <?php foreach ($gyanCats as $g): ?>
        <a href="<?= url('gyan.php?cat=' . $g['slug']) ?>" class="gyan-tile">
          <div class="gyan-ico">
            <svg viewBox="0 0 24 24"><path d="M12 3v18"/><path d="M6 8c3 0 6-2 6-5 0 3 3 5 6 5"/></svg>
          </div>
          <h3><?= e($g['name']) ?></h3>
          <p><?= e($g['description']) ?></p>
          <span class="cat-link">Explore →</span>
        </a>
      <?php endforeach; ?>
    </div>
  </div>
</section>

<!-- ═══════════════ ARTICLES ═══════════════ -->
<section class="section sand">
  <div class="container">
    <div class="section-head">
      <span class="eyebrow center">Spiritual Knowledge</span>
      <h2>Read, Learn &amp; Grow</h2>
      <p>Deeply researched articles on rituals, mantras and Hindu philosophy.</p>
    </div>
    <div class="article-grid">
      <?php foreach ($articles as $a): ?>
        <article class="article-card">
          <div class="ar-media">
            <?= img_tag($a['image_url'], $a['title']) ?>
            <span class="ar-cat"><?= e($a['category_name'] ?? 'Gyan') ?></span>
          </div>
          <div class="ar-body">
            <h3><a href="<?= url('article.php?slug=' . $a['slug']) ?>"><?= e($a['title']) ?></a></h3>
            <p><?= e($a['excerpt']) ?></p>
            <div class="ar-meta">
              <span><?= (int) $a['read_minutes'] ?> min read</span>
              <span class="dot"></span>
              <span><?= $a['published_at'] ? date('d M Y', strtotime($a['published_at'])) : '' ?></span>
            </div>
            <a href="<?= url('article.php?slug=' . $a['slug']) ?>" class="btn-ghost">Read Article →</a>
          </div>
        </article>
      <?php endforeach; ?>
    </div>
  </div>
</section>

<!-- ═══════════════ TRENDING ═══════════════ -->
<?php if (!empty($trending)): ?>
<section class="section">
  <div class="container">
    <div class="section-head">
      <span class="eyebrow center">Trending Now</span>
      <h2>Trending Topics</h2>
      <p>Latest articles on festivals, rituals, traditions and spiritual guidance.</p>
    </div>
    <div class="trend-grid">
      <?php $feature = array_shift($trending); ?>
      <article class="trend-feature">
        <?= img_tag($feature['image_url'], $feature['title']) ?>
        <div class="tf-content">
          <span class="tag"><?= e($feature['category_name'] ?? 'Featured') ?></span>
          <h3><?= e($feature['title']) ?></h3>
          <p><?= e($feature['excerpt']) ?></p>
          <a href="<?= url('article.php?slug=' . $feature['slug']) ?>" class="read">Read More →</a>
        </div>
      </article>

      <?php foreach ($trending as $t): ?>
        <article class="trend-small">
          <div class="ts-media"><?= img_tag($t['image_url'], $t['title']) ?></div>
          <div class="ts-body">
            <span class="ts-cat"><?= e($t['category_name'] ?? 'Gyan') ?></span>
            <h4><a href="<?= url('article.php?slug=' . $t['slug']) ?>"><?= e($t['title']) ?></a></h4>
            <span><?= (int) $t['read_minutes'] ?> min read</span>
          </div>
        </article>
      <?php endforeach; ?>
    </div>
  </div>
</section>
<?php endif; ?>

<!-- ═══════════════ FESTIVALS ═══════════════ -->
<section class="section sand" id="festivals">
  <div class="container">
    <div class="section-head">
      <span class="eyebrow center">Tithi &amp; Muhurat</span>
      <h2>Upcoming Festivals</h2>
      <p>Plan your puja, vrat and celebrations with our festival calendar.</p>
    </div>
    <div class="fest-grid">
      <?php foreach ($festivals as $f): ?>
        <article class="fest-card">
          <?= img_tag($f['image_url'], $f['name']) ?>
          <div class="fest-inner">
            <span class="fest-date">📅 <?= date('d M Y', strtotime($f['festival_date'])) ?></span>
            <h3><?= e($f['name']) ?></h3>
            <p><?= e($f['short_desc']) ?></p>
            <a href="<?= url('festival.php?slug=' . $f['slug']) ?>" class="btn-ghost">Explore →</a>
          </div>
        </article>
      <?php endforeach; ?>
    </div>
  </div>
</section>

<!-- ═══════════════ POPULAR PUJAS ═══════════════ -->
<section class="section" id="puja">
  <div class="container">
    <div class="section-head">
      <span class="eyebrow center">Book A Ritual</span>
      <h2>Popular Puja Services</h2>
      <p>Book authentic rituals performed by experienced priests at sacred temples.</p>
    </div>
    <div class="puja-grid">
      <?php foreach ($pujas as $p): ?>
        <article class="puja-card">
          <div class="pj-media">
            <?= img_tag($p['image_url'], $p['name']) ?>
            <?php if ($p['badge']): ?>
              <span class="pj-badge <?= e($p['badge_style']) ?>"><?= e($p['badge']) ?></span>
            <?php endif; ?>
            <?php if (!empty($p['city'])): ?>
              <span class="pj-loc">📍 <?= e($p['city']) ?></span>
            <?php endif; ?>
          </div>
          <div class="pj-body">
            <h3><?= e($p['name']) ?></h3>
            <p><?= e($p['short_desc']) ?></p>
            <div class="pj-foot">
              <div class="pj-price">
                <span>Starting at</span>
                <b><?= inr($p['price']) ?></b>
              </div>
              <a href="<?= url('puja.php?slug=' . $p['slug']) ?>" class="btn btn-terra btn-sm">Book Puja</a>
            </div>
          </div>
        </article>
      <?php endforeach; ?>
    </div>
  </div>
</section>

<!-- ═══════════════ DARK TEMPLES ═══════════════ -->
<?php if (!empty($templesDark)): ?>
<section class="section dark-temples">
  <div class="container">
    <div class="section-head">
      <span class="eyebrow center">Divine Destinations</span>
      <h2>Sacred Temples of Bharat</h2>
      <p>Explore sacred temples and experience divine blessings from India's most revered spiritual destinations.</p>
    </div>
    <div class="dark-temple-grid">
      <?php foreach ($templesDark as $t): ?>
        <article class="dark-temple-card">
          <div class="dt-media">
            <?= img_tag($t['image_url'], $t['name']) ?>
            <span class="dt-cat"><?= e($t['type']) ?></span>
            <span class="dt-loc">📍 <?= e($t['city']) ?></span>
          </div>
          <div class="dt-body">
            <h3><?= e($t['name']) ?></h3>
            <p><?= e($t['short_desc']) ?></p>
            <a href="<?= url('temple.php?slug=' . $t['slug']) ?>" class="btn btn-champagne btn-sm">Book Puja</a>
          </div>
        </article>
      <?php endforeach; ?>
    </div>
  </div>
</section>
<?php endif; ?>

<!-- ═══════════════ FAQ ═══════════════ -->
<section class="section" id="help">
  <div class="container">
    <div class="section-head">
      <span class="eyebrow center">Need Help?</span>
      <h2>Frequently Asked Questions</h2>
      <p>Everything you need to know about puja, prasad delivery and our services.</p>
    </div>
    <div class="faq-wrap">
      <?php foreach ($faqs as $f): ?>
        <div class="faq-item">
          <button class="faq-q" aria-expanded="false">
            <?= e($f['question']) ?>
            <span class="chev">▾</span>
          </button>
          <div class="faq-a">
            <p><?= nl2br(e($f['answer'])) ?></p>
          </div>
        </div>
      <?php endforeach; ?>
    </div>
  </div>
</section>

<!-- ═══════════════ NEWSLETTER ═══════════════ -->
<section class="section tight">
  <div class="container">
    <div class="newsletter">
      <div class="newsletter-mandala"></div>
      <div>
        <span class="eyebrow no-line">Divine Inbox</span>
        <h2>Stay Connected With Divine Wisdom</h2>
        <p>Receive festival updates, spiritual articles, puja offers and sacred insights directly in your inbox.</p>
      </div>
      <form class="nl-form" id="newsletterForm" novalidate>
        <?= csrf_field() ?>
        <div class="nl-row">
          <input type="email" id="newsletterEmail" name="email" placeholder="Enter your email address" autocomplete="email">
          <button type="submit" class="btn">Subscribe</button>
        </div>
        <p class="nl-msg" id="newsletterMsg"></p>
        <p class="nl-note">We respect your privacy. Unsubscribe anytime.</p>
      </form>
    </div>
  </div>
</section>

<?php require BASE_PATH . '/includes/footer.php'; ?>